//class AddressBook;
//class util;
#include<iostream>	
#include<fstream>						//for file handling	
#include<string.h>						//for string manipulation
#include<cctype>
#include<stdlib.h>						//for system("clear")
#include<math.h>
#include "util.cc"
using namespace std;
char directory[30];
class fileutil:public util{
public:
	long long mobile,landline;
	char name[30],email[50];
	int load_record(int record_number);	//This function accepts the record number as argument and loads the  data of the record into the object		
	int copy_into_temp();				//It copies all the record of file named as 'directory' in 'temp' and returns total records if error the 0
	int total_record();					//It returns the total no. of records in file
	int get_record_pos(char *name);	//It accepts the name and returns the position of the record of file. If record not found then returns -1
	int get_record_pos(long long mobile);	//It accepts the mobile no. and returns the position of the record of file. If record not found then returns -1
	int del(const char *name);			//It accepts the name as argument and delete that record from the file
	int del(long long mobile);				//It accepts the mobile no. as argument and delete that record from the file
	int replace(int pos,fileutil );
	//This function accets 3 arguments- first is position of the record in the file of which we want to replace the data
	//second is the name and 3rd is mobile.
	//It replace the previous values of 'name' and 'mobile' in file with 'name1' and mobile1 respectively
	//if unable to replace then return -1
	
	void init();						//It formats the file and put some records into it
		inline int size()					//It returns the size of the object of class AddressBook
	{
		return sizeof(fileutil);
	}
	inline void initialize(){
		name[0]='\0';
		mobile=0;
		landline=0;
		email[0]='\0';
	}
};	
void fileutil::init(){
	ofstream obj;
	obj.open(directory);
	strcpy(name,"Ashish Doneriya");
	mobile=9301124836;
	strcpy(email,"ashishdoneriya@ymail.com");
	obj.write((char *)this,size());
	strcpy(name,"My Old mobile");
	mobile=7898330674;
	strcpy(email,"ashishdoneriya@gmail.com");
	obj.write((char *)this,size());
	strcpy(name,"My Home mobile");
	mobile=9301376952;
	strcpy(email,"donad@ymail.com");
	obj.write((char *)this,size());
	obj.close();
}
int fileutil::copy_into_temp(){
	ifstream in;
	ofstream out;
	int rcd=total_record();
	in.open(directory);
	out.open("temp");
	if (!in||!out){
		return 0;
	}
	for(int i=0;i<rcd;i++){
		in.read((char *)this,size());
		out.write((char *)this,size());
	}
	in.close();
	out.close();
	return rcd;
}
int fileutil::total_record(){
	int i=0;
	ifstream obj;
	obj.open(directory);
	if(!obj){
		cout<<"File can't be opened";
		getchar();
		return 0;
	}
	for(i=0;obj.eof()==0;i++)
		obj.read((char *)this,size());
	return i;
}
int fileutil::get_record_pos(char *name){
	ifstream obj;
	obj.open(directory);
	if(!obj){
		cout<<"File can't be opened";
		getchar();
	}
	else if(strlen(name)==0){}
	else if (strchr(email,'@')!=0){
		while(!obj.eof()){
			obj.read((char *)this,size());
			if(!strcmp(email,this->email)){
				return (obj.tellg())/size();
			}
		}
	}
	while(!obj.eof()){
		obj.read((char *)this,size());
		if(!strcomp(name,this->name)){
			return (obj.tellg())/size();	
		}
	}
	obj.close();
	return 0;
}
int fileutil::get_record_pos(long long mobile){
	ifstream obj;
	int pos;
	obj.open(directory);
	if(!obj){
		cout<<"File can't be opened";
		getchar();
		return 0;
	}
	while(!obj.eof()){
		obj.read((char *)this,size());
		if(this->mobile==mobile){
			pos=(obj.tellg())/size();
			obj.close();
			return pos;
		}
	}
	obj.close();
	return 0;
}
int fileutil::load_record(int rcd){
	ifstream obj;
	obj.open(directory);
	if(!obj)
		return 0;
	int i=0;
	while(1){
		if(obj.eof()!=0)
			break;
		obj.read((char *)this,size());
		if(i++==rcd-1)
			return 1;
	}
	return 0;
}
int fileutil::replace(int rcd, fileutil T){
	ifstream in;
	ofstream out;
	int total_rcd=copy_into_temp();
	if(total_rcd==0)
		return 0;
	in.open("temp");
	out.open(directory);
	if (!in||!out)
		return 0;
	
	for(int i=0;i<total_rcd-1;i++){
		in.read((char*)this,size());
		if(i==rcd-1){
			strcpy(this->name,T.name);
			this->mobile=T.mobile;
			this->landline=T.landline;
			this->mobile=T.mobile;
		}
		out.write((char*)this,size());		
	}
	in.close();
	out.close();
	remove("temp");
	return 1;
}
int fileutil::del(long long phone){
	ifstream in;
	ofstream out;
	int flag=0;
	int rcd=copy_into_temp();
	if(	rcd==-1)
		return -1;
	in.open("temp");
	out.open(directory);
	if (!in||!out)
		return -1;
	for(int i=0;i<rcd-1;i++){
		in.read((char *)this,size());
		if ((this->mobile!=phone)&&(this->landline!=phone)){
			out.write((char *)this,size());
			continue;
		}
		flag++;
	}
	in.close();
	out.close();
	return flag;
}
int fileutil::del(const char *str){
	ifstream in;
	ofstream out;
	int flag=0;
	int rcd=copy_into_temp();
	if(	rcd==-1)
		return -1;
	in.open("temp");
	out.open(directory);
	if (!in||!out){
		return -1;
	}
	for(int i=0;i<rcd-1;i++){
		in.read((char *)this,size());
		if ((strcomp(str,this->name)!=0)&&(strcomp(str,this->email)!=0)){
	//	if (strcomp(str,this->email)!=0){
			out.write((char *)this,size());
			continue;
		}
		flag++;
	}
	in.close();
	out.close();
	return flag;
}
