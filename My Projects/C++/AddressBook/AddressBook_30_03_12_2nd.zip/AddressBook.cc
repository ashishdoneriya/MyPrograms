//                                    ::HARE KRISHNA::
// 										ADDRESS BOOK
//NAME    :: ASHISH DONERIYA
//COLLEGE ::MANIT
//INSPIRE BHOPAL
#include<iostream>						//for cin and cout
#include<fstream>						//for file handling	
#include<string.h>						//for string manipulation
#include<cctype>
#include<cstring>
#include<stdlib.h>						//for system("clear")
#include<math.h>						//for math functions
#include "fileutil.cc"
using namespace std;
class AddressBook;
class AddressBook:public fileutil{
public:
	void createfile();
	void flush();						//It clears the buffer	
	void get() throw (invalidMobile,invalidLandline,invalidEmailid);							//It accepts the name and mobile no. from user and save it in object of class AddressBook
	void show();						//It shows the data inside 'name' and 'mobile' variables of object of class AddressBook
	void advance_search();
	void extreme_search();	
	void addition();					//It is used for adding the record in the file
	void display();						//It displays all the record of the file
	void modify();						//It is used to modify an existing record in the file
	void search();						//It is used to search and display a particular record of file
	void deletion();					//It is used to delete a particular record form the file
	void menu_screen();					//It displays the list of tasks that can be done on a file or it displays the options for address book
	void welcome_screen();				//It displays the welcome screen
};
void AddressBook::createfile(){
	//cout<<"Enter the file name : ";
	//cin.getline(directory,30);
	strcpy(directory,"a");
	fstream obj;
	obj.open(directory,ios::app);
	obj.close();
}
void AddressBook::extreme_search(){
	ifstream obj;
	int i=0,j=0,len,count;
	char str[30],**str1;
	try{
		obj.open(directory);
		if(!obj)
			throw FileNotFoundException();
		system("clear");
		cout<<"Enter name or mobile no. : ";
		cin.getline(str,30);
		len=strlen(str);
		if(len==0)
			return;
	
		if(check_number(str)==1&&len<=10){
			for(i=0,count=0;i<total_record()-1;i++){
				obj.read((char *)this,size());
				if(strcmp_adv(mobile,get_mobile(str),len)==1){
					show();
					count=count+1;		
				}
			}
			if(count==0)
				throw NoRecordFoundException();
		}
		else{
			for(i=0,count=0;i<total_record()-1;i++){
				obj.read((char *)this,size());
				str1=get_combinations(str);
				for(j=0;j<4;j++){
					if((strcmp_adv(name,str1[j])==1)||strcomp(email,str)!=-1){
						show();
						count=count+1;
						break;
					}
				}
			}
			if(count==0)
				throw NoRecordFoundException();
			else
				cout<<"\n"<<count<<" records found"<<endl;
		}
	}
	catch(FileNotFoundException fe){
		cout<<fe.str<<endl;
	}
	catch(NoRecordFoundException r){
		cout<<r.str<<endl;
	}
	getchar();
	obj.close();
}
void AddressBook::advance_search(){
	ifstream obj;
	int i=0,flag,len,count;
	char str[30];
	obj.open(directory);
	if(!obj){
		cout<<"File can't be opened";
		getchar();
		return;
	}
	system("clear");
	cout<<"Enter name or mobile no. : ";
	cin.getline(str,30);
	len=strlen(str);
	if(len==0){
		cout<<"No record found";
		getchar();
		return;
	}
	if(check_number(str)==1&&len<=10){
		for(i=0,count=0;i<total_record()-1;i++){
			obj.read((char *)this,size());
			if((long long)(mobile/(pow(10,10-len)))==get_mobile(str)){
				show();
				count=count+1;
			}
		}
		if(count==0)
			cout<<"No record found"<<endl;
	}
	else{
		for(i=0,count=0;i<total_record()-1;i++){
			obj.read((char *)this,size());
			flag=strcomp(name,str);
			if(flag==1||flag==0){
				show();
				count=count+1;
			}
		}
		if(count==0)
			cout<<"No record found"<<endl;
		else
			cout<<"\n"<<count<<" records found"<<endl;
	}
	//flush();
	getchar();
	obj.close();
}
void AddressBook::flush(){
	scanf ( "%*[^\n]" );
	scanf ( "%*c" );
}
void AddressBook::get() throw (invalidMobile,invalidLandline,invalidEmailid){
	char ch,temp[50];
	initialize();
	aaaaa:
	try{
		cout<<"ENTER NAME    :: ";
		cin.getline(temp,30);
		if(strlen(temp)==0)
			throw message("Please Enter a Valid Name");
	}
	catch(message m){
		cout<<m.str<<endl;
		goto aaaaa;
	}
    strcpy(name,Upper_Lower(temp));
    
    cout<<"Mobile Number :: ";
	cin.getline(temp,30);
	if(strlen(temp)!=0){
		if(!valid_num(temp)){
			throw invalidMobile();
		}
		else
			mobile=get_mobile(temp);
	}
	cout<<"Landline      :: ";
	cin.getline(temp,30);
	if(strlen(temp)!=0){
		if(!check_number(temp)){
			throw invalidLandline();
		}
		else
			landline=get_mobile(temp);
		cin.get(ch);
	}
	cout<<"Email id :    : ";
	cin.getline(temp,49);
	if(strlen(temp)!=0){
		if (index(email,'@')){
			throw invalidEmailid();
		}
		else
			strcpy(email,temp);
	}
}
void AddressBook::show(){
	cout<<"Name         :: "<<name<<endl;
	cout<<"Mobile No.   :: "<<mobile<<endl;
	cout<<"Landline No. :: "<<landline<<endl;
	cout<<"Email-id     :: "<<email<<"\n"<<endl;
}
void AddressBook::addition(){
	try{
		get();
	}
	catch (invalidMobile m){
		cout<<m.str<<endl;
		getchar();
		return;
	}
	catch (invalidLandline l){
		cout<<l.str<<endl;
		getchar();
		return;
	}
	catch (invalidEmailid e){
		cout<<e.str<<endl;
		getchar();
		return;
	}
	add_ascending(*this);
}
void AddressBook::display(){
	int i=1;
	ifstream obj;
	system("clear");
	try{
		obj.open(directory);
		if(!obj)
			throw FileNotFoundException();
	}
	catch(FileNotFoundException fe){
		cout<<fe.str<<endl;
		getchar();
		return;
	}
	while(1){
		obj.read((char *)this,size());
		if(obj.eof()!=0)
			break;
		show();
		if((i++)%5==0){
			getchar();
			system("clear");
		}
	}
	flush();
	obj.close();
}
void AddressBook::search(){
	ifstream obj;
	int pos;
	char str[30];
	obj.open(directory);
	try{
		obj.open(directory);
		if(!obj)
			throw FileNotFoundException();
		system("clear");
		cout<<"Enter name or mobile no. : ";
		cin.getline(str,30);
		if(strlen(str)==0)
		return;
		if(valid_num(str)==1){
//			long long ph=get_mobile(str);
			pos=get_record_pos(get_mobile(str));
			obj.seekg((pos-1)*size(),ios::beg);
			obj.read((char *)this,size());
			show();
			getchar();
		}
		else{
			pos=get_record_pos(str);
			obj.seekg((pos-1)*size(),ios::beg);
			obj.read((char *)this,size());
			show();
		}
	}
	catch(FileNotFoundException f){
		cout<<f.str<<endl;
	}
	catch(NoRecordFoundException nr){
		cout<<nr.str<<endl;
	}
	getchar();
	obj.close();
}
void AddressBook::modify(){
	char str[30]="";
	AddressBook T;
	system("clear");
	cout<<"Enter Name or mobile Number : ";
	cin.getline(str,30);
	try{
		if(valid_num(str)==1)
			load_record(get_record_pos(get_mobile(str)));
		else
			load_record(get_record_pos(str));
	}
	catch(FileNotFoundException e){
		cout<<e.str<<endl;
		getchar();
		return;
	}
	catch(NoRecordFoundException e){
		cout<<e.str<<endl;
		getchar();
		return;
	}	
		T=*this;
		cout<<this->name<<endl;
		getchar();
		char temp[50];
		cout<<"Enter new name : ";
		cin.getline(temp,30);
		if(strlen(temp)!=0)
			strcpy(name,Upper_Lower(temp));
		cout<<mobile<<endl;
		cout<<"Enter new mobile number : ";
		cin.getline(temp,30);
		if(strlen(temp)!=0){
			if(valid_num(temp)==1)
				mobile=get_mobile(temp);
			else
				cout<<"Invalid mobile no."<<endl;	
		}
		cout<<landline<<endl;
		cout<<"Enter new landline no. : ";
		cin.getline(temp,30);
		if(strlen(temp)!=0){
			if(check_number(temp)==1)	{landline=get_mobile(temp);}
			else 						{cout<<"Invalid Landline"<<endl;}
		}
		cout<<email<<endl;
		cout<<"Enter new email id : ";
		cin.getline(temp,50);
		if(strlen(temp)!=0){
			if(strchr(email,'@')!=0)	{strcpy(email,temp);}
				else 						{cout<<"Invalid email";}
		}
	//	replace(pos,T);
		try{
			add_ascending(*this);
			del(T.name);
		}
		catch(FileNotFoundException e){
			cout<<e.str<<endl;
		}
		catch(NoRecordFoundException e){
			cout<<e.str<<endl;
		}
	getchar();
}
void AddressBook::deletion(){
	char str[30];
	cout<<"Enter name or number to be deleted : ";
	cin.getline(str,30);
	if(strlen(str)==0)
		return;
	try{
		if(valid_num(str)==1)
			del(get_mobile(str));
		else{
			strcpy(str,Upper_Lower(str));
			del(str);
		}
	}
	catch(FileNotFoundException e){
		cout<<e.str<<endl;
	}
	catch(NoRecordFoundException e){
		cout<<e.str<<endl;
	}
	getchar();
}
void AddressBook::menu_screen(){
	char ch;
	do{
		system("clear");
		cout<<"		          :: ADDRESS BOOK::"<<endl;
		cout<<"A::Add"<<endl;
		cout<<"V::View"<<endl;
		cout<<"S::Search"<<endl;
		cout<<"s::Advance Search"<<endl;
		cout<<"e::Extreme Search"<<endl;
		cout<<"M::Modify"<<endl;
		cout<<"d::Delete record"<<endl;
		cout<<"F::Format The File"<<endl;
		cout<<"R::Remove A File"<<endl;
		cout<<"G::Goto Another File"<<endl;
		cout<<"E::Exit"<<endl;
		cout<<"Enter your choice : "<<endl;
		char str[100];
		cin.getline(str,100);
	    if(strlen(str)>1)
			continue;
		else
		ch=str[0];
		switch (ch){
			case 'A':
			case 'a':
				addition();
				break;
			case 'V':
			case 'v':
				display();
				break;
			case 's':
				advance_search();
				break;
			case 'S':
				search();
				break;
			case 'M':
			case 'm':
				modify();
				break;
			case 'D':
			case 'd':
				deletion();
				break;
			case 'F':
			case 'f':{
					ofstream obj;
					obj.open(directory);
					obj.close();
					cout<<"Formatted";
					//flush();
					getchar();
					break;
			}
			case 'e':
				extreme_search();
				break;
			case 'G':
			case 'g':
				createfile();
				break;
			case 'E':
				return;
			case 'r':
			case 'R':
				cout<<"Enter the file name : ";
				char rem[30];
				cin.getline(rem,30);
				remove(rem);
				break;
			default:
				cout<<"Wrong Choice"<<endl;
		}
	}while(ch!='E'||ch!='e');
}
void AddressBook::welcome_screen(){
	system("clear");
	cout<<"+++++++++++++++++++++++++++++++++++++++++++++++++++++++++"<<endl;
	cout<<"		           ADDRESS BOOK"<<endl;
	cout<<"+++++++++++++++++++++++++++++++++++++++++++++++++++++++++"<<endl;
	cout<<"\n\n\n\nPress any key to continue................";
	getchar();
}
int main(){
	AddressBook T;
	T.createfile();
//	T.welcome_screen();
	T.init();
	T.menu_screen();
	return 0;
}
