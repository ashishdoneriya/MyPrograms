//class AddressBook;
//class util;
#include<iostream>	
#include<fstream>						//for file handling	
#include<string.h>						//for string manipulation
#include<cctype>
#include<stdlib.h>						//for system("clear")
#include<math.h>
#include "util.cc"
#include "exceptions.cc"
using namespace std;
char directory[30];
//-------------------------------------------------------------------------------------------------
class fileutil:public util{
public:

	long long mobile,landline;
	char name[30],email[50];
	void loadRecord(int record_number) throw (FileNotFoundException, NoRecordFoundException);
	//This function accepts the record number as argument and loads the  data of the record into the object		

	int copyIntoTemp() throw (FileNotFoundException);
	//It copies all the record of file named as 'directory' in 'temp' and returns total records if error the 0

	int getTotalRecords() throw (FileNotFoundException);
	//It returns the total no. of records in file

	int getRecordPos(char *name) throw (FileNotFoundException, NoRecordFoundException);
	//It accepts the name and returns the position of the record of file. If record not found then returns -1

	int getRecordPos(long long mobile) throw (FileNotFoundException, NoRecordFoundException);
	//It accepts the mobile no. and returns the position of the record of file. If record not found then returns -1

	void del(const char *name) throw (FileNotFoundException, NoRecordFoundException);
	//It accepts the name as argument and delete that record from the file

	void del(long long mobile) throw (FileNotFoundException, NoRecordFoundException);
	//It accepts the mobile no. as argument and delete that record from the file

	int replace(int pos,fileutil ) throw (FileNotFoundException);

	int addAscending(fileutil) throw (FileNotFoundException);

	void del(fileutil) throw (FileNotFoundException, NoRecordFoundException);
	/* This function accets 3 arguments- first is position of the record in the file of which we want to replace the data
	 * second is the name and 3rd is mobile.
	 * It replace the previous values of 'name' and 'mobile' in file with 'name1' and mobile1 respectively
	 * if unable to replace then return -1
	 */

	int addAscending(char *name,long long mobile,long long landline,char *email);

	int addAscending() throw (FileNotFoundException);

	void init();
	//It formats the file and put some records into it

	inline int size()	//It returns the size of the object of class AddressBook
	{
		return sizeof(fileutil);
	}
	inline void initialize(){
		name[0]='\0';
		mobile=0;
		landline=0;
		email[0]='\0';
	}
	int operator != (fileutil f1);
/*	fileutil(char *name,long long mobile,long long landline,char *email){
		strcpy(this->name,name);
		strcpy(this->email,email);
		this->mobile=mobile;
		this->landline=landline;
	}*/
	fileutil(){};
};
//-------------------------------------------------------------------------------------------------
int fileutil::operator != (fileutil f1){
	if((strcmp(this->name,f1.name)!=0)||(this->mobile!=f1.mobile)) {return 1;}
	else {return 0;}
}
//-------------------------------------------------------------------------------------------------
int fileutil::addAscending(fileutil T) throw (FileNotFoundException){
	ifstream in;
	ofstream out;
	int rcd=copyIntoTemp();
	int i=0;
	if(	rcd==-1){return -1;}
	in.open("temp");
	out.open(directory);
	if (!in||!out)
		throw FileNotFoundException();
	
	int flag=1;
	for(i=0;i<rcd-1;i++){
		in.read((char*)this,size());
		if((strcmp(T.name,name)==(-1))&&flag==1){
			out.write((char *)&T,size());
			flag=0;
		}
		out.write((char*)this,size());			
	}
	if(flag==1)
		out.write((char *)&T,size());
	remove("temp");
	in.close();
	out.close();
}
//-------------------------------------------------------------------------------------------------
int fileutil::addAscending() throw (FileNotFoundException){
	ifstream in;
	ofstream out;
	int rcd=copyIntoTemp();
	int i=0;
	if(	rcd==-1){return -1;}
	in.open("temp");
	out.open(directory);
	if (!in||!out)
		throw FileNotFoundException();
	fileutil T=*this;
	int flag=1;
	for(i=0;i<rcd-1;i++){
		in.read((char*)this,size());
		if((strcmp(T.name,name)==(-1))&&flag==1){
			out.write((char *)&T,size());
			flag=0;
		}
		out.write((char*)this,size());			
	}
	if(flag==1)
		out.write((char *)&T,size());
	remove("temp");
	in.close();
	out.close();
}
/*
int fileutil::addAscending(char *name,long long mobile,long long landline,char *email){
	ifstream in;
	ofstream out;
	int rcd=copyIntoTemp();
	int i=0;
	if(	rcd==-1){return -1;}
	in.open("temp");
	out.open(directory);
	if (!in||!out){
		cout<<"Can't add the record"<<endl;
		getchar();
		return -1;
	}
	fileutil T(char *name,long long mobile,long long landline,char *email);
	int flag=1;
	for(i=0;i<rcd-1;i++){
		in.read((char*)this,size());
		if((strcmp(T.name,this->name)==(-1))&&flag==1){
			out.write((char *)&T,size());
			flag=0;
		}
		out.write((char*)this,size());			
	}
	if(flag==1)
		out.write((char *)&T,size());
	remove("temp");
	in.close();
	out.close();
}*/
void fileutil::init(){
	ofstream obj;
	obj.open(directory);
	strcpy(name,"Ashish Doneriya");
	mobile=9301124836;
	strcpy(email,"ashishdoneriya@ymail.com");
	obj.write((char *)this,size());
	strcpy(name,"My Old mobile");
	mobile=7898330674;
	strcpy(email,"ashishdoneriya@gmail.com");
	obj.write((char *)this,size());
	strcpy(name,"My Home mobile");
	mobile=9301376952;
	strcpy(email,"ad@ymail.com");
	obj.write((char *)this,size());
	obj.close();
}
//-------------------------------------------------------------------------------------------------
int fileutil::copyIntoTemp() throw (FileNotFoundException){
	ifstream in;
	ofstream out;
	int rcd=getTotalRecords();
	in.open(directory);
	out.open("temp");
	if (!in||!out)
		throw FileNotFoundException();
	for(int i=0;i<rcd;i++){
		in.read((char *)this,size());
		out.write((char *)this,size());
	}
	in.close();
	out.close();
	return rcd;
}
//-------------------------------------------------------------------------------------------------
int fileutil::getTotalRecords() throw (FileNotFoundException){
	int i=0;
	ifstream obj;
	obj.open(directory);
	if(!obj)
		throw FileNotFoundException();
	for(i=0;obj.eof()==0;i++)
		obj.read((char *)this,size());
	return i;
}
//-------------------------------------------------------------------------------------------------
int fileutil::getRecordPos(char *str) throw (FileNotFoundException, NoRecordFoundException){
	ifstream obj;
	obj.open(directory);
	if(!obj)
		throw FileNotFoundException();
	else if(strlen(name)==0){}
	else{
		if (strchr(email,'@')!=0){
			while(!obj.eof()){
				obj.read((char *)this,size());
				if(!strcmp(str,this->email)){
					return (obj.tellg())/size();
				}
			}
		}
		obj.close();
		obj.open(directory);
		while(!obj.eof()){
			obj.read((char *)this,size());
			if(strcomp(str,this->name)==0){
				return (obj.tellg())/size();	
			}
		}
	}
	obj.close();
	throw NoRecordFoundException();
}
//-------------------------------------------------------------------------------------------------
int fileutil::getRecordPos(long long mobile) throw (FileNotFoundException, NoRecordFoundException){
	ifstream obj;
	int pos;
	obj.open(directory);
	if(!obj)
		throw FileNotFoundException();
	while(!obj.eof()){
		obj.read((char *)this,size());
		if(this->mobile==mobile){
			pos=(obj.tellg())/size();
			obj.close();
			return pos;
		}
	}
	obj.close();
	throw NoRecordFoundException();
}
//-------------------------------------------------------------------------------------------------
void fileutil::loadRecord(int rcd) throw (FileNotFoundException, NoRecordFoundException){
	ifstream obj;
	obj.open(directory);
	if(!obj)
		throw FileNotFoundException();
	if (rcd>getTotalRecords())
		throw NoRecordFoundException();
		cout<<"RECORD NO + "<<rcd<<endl;
	obj.seekg(size()*(rcd-1),ios::beg);
	obj.read((char *)this,size());
}
//-------------------------------------------------------------------------------------------------
int fileutil::replace(int rcd, fileutil T) throw (FileNotFoundException){
	ifstream in;
	fstream out;
	int total_rcd=copyIntoTemp();
	if(total_rcd==0)
		return 0;
	in.open("temp");
	remove(directory);
	out.open(directory);
	if (!in||!out)
		throw FileNotFoundException();
	
	for(int i=0;i<total_rcd-1;i++){
		in.read((char*)this,size());
		if(i==rcd-1){
			strcpy(this->name,T.name);
			this->mobile=T.mobile;
			this->landline=T.landline;
			strcpy(this->email,T.email);
			out.close();
			addAscending(T);
			out.open(directory,ios::app);
		}
		else
			out.write((char*)this,size());		
	}
	in.close();
	out.close();
	remove("temp");
	return 1;
}
//-------------------------------------------------------------------------------------------------
void fileutil::del(fileutil T) throw (FileNotFoundException, NoRecordFoundException){
	ifstream in;
	ofstream out;
	int flag=0;
	int rcd=copyIntoTemp();
	in.open("temp");
	out.open(directory);
	if (!in||!out)
		throw FileNotFoundException();
	for(int i=0;i<rcd-1;i++){
		in.read((char *)this,size());
		if (T!=*this){
			out.write((char *)this,size());
			continue;
		}
		flag++;
	}
	in.close();
	out.close();
	remove("temp");
	if (flag==0)
		throw NoRecordFoundException();
}
//-------------------------------------------------------------------------------------------------
void fileutil::del(long long phone) throw (FileNotFoundException, NoRecordFoundException){
	ifstream in;
	ofstream out;
	int flag=0;
	int rcd=copyIntoTemp();
	in.open("temp");
	out.open(directory);
	if (!in||!out)
		throw FileNotFoundException();
	for(int i=0;i<rcd-1;i++){
		in.read((char *)this,size());
		if ((this->mobile!=phone)&&(this->landline!=phone)){
			out.write((char *)this,size());
			continue;
		}
		flag++;
	}
	in.close();
	out.close();
	remove("temp");
	if (flag==0)
		throw NoRecordFoundException();
}
//-------------------------------------------------------------------------------------------------
void fileutil::del(const char *str) throw (FileNotFoundException, NoRecordFoundException){
	ifstream in;
	ofstream out;
	int flag=0;
	int rcd=copyIntoTemp();
	in.open("temp");
	out.open(directory);
	if (!in||!out)
		throw FileNotFoundException();
	for(int i=0;i<rcd-1;i++){
		in.read((char *)this,size());
		if ((strcomp(str,this->name)!=0)&&(strcomp(str,this->email)!=0)){
	//	if (strcomp(str,this->email)!=0){
			out.write((char *)this,size());
			continue;
		}
		flag++;
	}
	in.close();
	out.close();
	remove("temp");
	if (flag==0)
		throw NoRecordFoundException();
}
