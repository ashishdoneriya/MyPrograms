//                                    ::HARE KRISHNA::
// 										ADDRESS BOOK
//NAME    :: ASHISH DONERIYA
//COLLEGE ::MANIT
//INSPIRE BHOPAL
#include<iostream>
#include<fstream>
#include<string.h>
#include<cctype>
#include<cstring>
#include<stdlib.h>
#include<math.h>
#include<conio.h>
#include "fileutil.cc"
using namespace std;
class AddressBook;
class AddressBook:public fileutil{
public:
	void createFile() throw (Exception);
	
	void flush();
	//It clears the buffer	
	
	void get() throw (InvalidMobileException, InvalidLandlineException, InvalidEmailException);
	//It accepts the name and mobile no. from user and save it in object of class AddressBook
	
	void show();
	//It shows the data inside 'name' and 'mobile' variables of object of class AddressBook

	void search();
	//It is used to search and display a particular record of file

	void advanceSearch();
	void extremeSearch();	

	void addition();
	//It is used for adding the record in the file

	void display();
	//It displays all the record of the file

	void modify();
	//It is used to modify an existing record in the file

	void deletion();
	//It is used to delete a particular record form the file

	void menuScreen();
	//It displays the list of tasks that can be done on a file or it displays the options for address book

	void welcomeScreen();
	//It displays the welcome screen
};
//=========================================================================
void AddressBook::createFile() throw (Exception){
repeat:
	cout<<"Enter the file name : ";
	cin.getline(directory,30);
	if(strlen(directory)==0){
		cout<<"Please Enter the file name"<<endl;
		goto repeat;
	}
	fstream obj;
	obj.open(directory,ios::app);
	if(!obj)
		throw Exception("File can't be opened or created");
	obj.close();
}
//=========================================================================
void AddressBook::extremeSearch(){
	ifstream obj;
	int i=0,j=0,len,count;
	char str[30],**str1;
	try{
		obj.open(directory);
		if(!obj)
			throw FileNotFoundException();
		system("clear");
		cout<<"Enter name or mobile no. : ";
		cin.getline(str,30);
		len=strlen(str);
		if(len==0)
			return;
	
		if(isValidNumber(str)==true&&len<=10){
			for(i=0,count=0;i<getTotalRecords()-1;i++){
				obj.read((char *)this,size());
				if(strcmpAdv(mobile,getNumber(str),len)==1){
					show();
					count=count+1;		
				}
			}
			if(count==0)
				throw NoRecordFoundException();
		}
		else{
			for(i=0,count=0;i<getTotalRecords()-1;i++){
				obj.read((char *)this,size());
				str1=getCombinations(str);
				for(j=0;j<4;j++){
					if((strcmpAdv(name,str1[j])==1)||strcomp(email,str)!=-1){
						show();
						count=count+1;
						break;
					}
				}
			}
			if(count==0)
				throw NoRecordFoundException();
			else
				cout<<"\n"<<count<<" records found"<<endl;
		}
	}
	catch(FileNotFoundException fe){
		cout<<fe.str<<endl;
	}
	catch(NoRecordFoundException r){
		cout<<r.str<<endl;
	}
	getchar();
	obj.close();
}
//=========================================================================
void AddressBook::advanceSearch(){
	ifstream obj;
	int i=0,flag,len,count;
	char str[30];
	obj.open(directory);
	if(!obj){
		cout<<"File can't be opened";
		getchar();
		return;
	}
	system("clear");
	cout<<"Enter name or mobile no. : ";
	cin.getline(str,30);
	len=strlen(str);
	if(len==0){
		cout<<"No record found";
		getchar();
		return;
	}
	if(isValidNumber(str)==true&&len<=10){
		for(i=0,count=0;i<getTotalRecords()-1;i++){
			obj.read((char *)this,size());
			if((long long)(mobile/(pow(10,10-len)))==getNumber(str)){
				show();
				count=count+1;
			}
		}
		if(count==0)
			cout<<"No record found"<<endl;
	}
	else{
		for(i=0,count=0;i<getTotalRecords()-1;i++){
			obj.read((char *)this,size());
			flag=strcomp(name,str);
			if(flag==1||flag==0){
				show();
				count=count+1;
			}
		}
		if(count==0)
			cout<<"No record found"<<endl;
		else
			cout<<"\n"<<count<<" records found"<<endl;
	}
	//flush();
	getchar();
	obj.close();
}
//=========================================================================
void AddressBook::flush(){
	scanf ( "%*[^\n]" );
	scanf ( "%*c" );
}
//=========================================================================
void AddressBook::get() throw (InvalidMobileException, InvalidLandlineException, InvalidEmailException){
	char ch,temp[50];
	initialize();
	aaaaa:
	try{
		cout<<"ENTER NAME    :: ";
		cin.getline(temp,30);
		if(strlen(temp)==0)
			throw Exception("Please Enter a Valid Name");
	}
	catch(Exception e){
		cout<<e.str<<endl;
		goto aaaaa;
	}
    strcpy(name,UpperLower(temp));
    
    cout<<"Mobile Number :: ";
	cin.getline(temp,30);
	if(strlen(temp)!=0){
		if(!isValidMobile(temp)){
			throw InvalidMobileException();
		}
		else
			mobile=getNumber(temp);
	}
	cout<<"Landline      :: ";
	cin.getline(temp,30);
	if(strlen(temp)!=0){
		if(isValidNumber(temp)==false){
			throw InvalidLandlineException();
		}
		else
			landline=getNumber(temp);
		cin.get(ch);
	}
	cout<<"Email id :    : ";
	cin.getline(temp,49);
	if(strlen(temp)!=0){
		if (index(email,'@')){
			throw InvalidEmailException();
		}
		else
			strcpy(email,temp);
	}
}
//=========================================================================
void AddressBook::show(){
	cout<<"Name         :: "<<name<<endl;
	cout<<"Mobile No.   :: "<<mobile<<endl;
	cout<<"Landline No. :: "<<landline<<endl;
	cout<<"Email-id     :: "<<email<<"\n"<<endl;
}
//=========================================================================
void AddressBook::addition(){
	try{
		get();
	}
	catch (InvalidMobileException m){
		cout<<m.str<<endl;
		getch();
		return;
	}
	catch (InvalidLandlineException l){
		cout<<l.str<<endl;
		getch();
		return;
	}
	catch (InvalidEmailException e){
		cout<<e.str<<endl;
		getch();
		return;
	}
	addAscending(*this);
}
//=========================================================================
void AddressBook::display(){
	int i=1;
	ifstream obj;
	system("clear");
	try{
		obj.open(directory);
		if(!obj)
			throw FileNotFoundException();
	}
	catch(FileNotFoundException fe){
		cout<<fe.str<<endl;
		getch();
		return;
	}
	while(1){
		obj.read((char *)this,size());
		if(obj.eof()!=0)
			break;
		show();
		if((i++)%5==0){
			getch();
			system("clear");
		}
	}
	flush();
	obj.close();
}
//=========================================================================
void AddressBook::search(){
	ifstream obj;
	int pos;
	char str[30];
	obj.open(directory);
	try{
		obj.open(directory);
		if(!obj)
			throw FileNotFoundException();
		system("clear");
		cout<<"Enter name or mobile no. : ";
		cin.getline(str,30);
		if(strlen(str)==0)
		return;
		if(isValidMobile(str)==1){
//			long long ph=getNumber(str);
			pos=getRecordPos(getNumber(str));
			obj.seekg((pos-1)*size(),ios::beg);
			obj.read((char *)this,size());
			show();
			getchar();
		}
		else{
			pos=getRecordPos(str);
			obj.seekg((pos-1)*size(),ios::beg);
			obj.read((char *)this,size());
			show();
		}
	}
	catch(FileNotFoundException f){
		cout<<f.str<<endl;
	}
	catch(NoRecordFoundException nr){
		cout<<nr.str<<endl;
	}
	getchar();
	obj.close();
}
//=========================================================================
void AddressBook::modify(){
	char str[30]="";
	AddressBook T;
	system("clear");
	cout<<"Enter Name or mobile Number : ";
	cin.getline(str,30);
	try{
		if(isValidMobile(str)==1)
			loadRecord(getRecordPos(getNumber(str)));
		else
			loadRecord(getRecordPos(str));
	}
	catch(FileNotFoundException e){
		cout<<e.str<<endl;
		getchar();
		return;
	}
	catch(NoRecordFoundException e){
		cout<<e.str<<endl;
		getchar();
		return;
	}	
		T=*this;
		cout<<this->name<<endl;
		getchar();
		char temp[50];
		cout<<"Enter new name : ";
		cin.getline(temp,30);
		if(strlen(temp)!=0)
			strcpy(this->name,UpperLower(temp));
		cout<<mobile<<endl;
		cout<<"Enter new mobile number : ";
		cin.getline(temp,30);
		if(strlen(temp)!=0){
			if(isValidMobile(temp)==1)
				this->mobile=getNumber(temp);
			else
				cout<<"Invalid mobile no."<<endl;	
		}
		cout<<landline<<endl;
		cout<<"Enter new landline no. : ";
		cin.getline(temp,30);
		if(strlen(temp)!=0){
			if(isValidNumber(temp)==true)	{this->landline=getNumber(temp);}
			else 						{cout<<"Invalid Landline"<<endl;}
		}
		cout<<email<<endl;
		cout<<"Enter new email id : ";
		cin.getline(temp,50);
		if(strlen(temp)!=0){
			if(strchr(email,'@')!=0)	{strcpy(this->email,temp);}
				else 						{cout<<"Invalid email";}
		}
	//	replace(pos,T);
		try{
			if(T!=*this){
				addAscending(*this);
				del(T.name);
			}
		}
		catch(FileNotFoundException e){
			cout<<e.str<<endl;
		}
		catch(NoRecordFoundException e){
			cout<<e.str<<endl;
		}
	getch();
}
//=========================================================================
void AddressBook::deletion(){
	char str[30];
	cout<<"Enter name or number to be deleted : ";
	cin.getline(str,30);
	if(strlen(str)==0)
		return;
	try{
		if(isValidMobile(str)==1)
			del(getNumber(str));
		else{
			strcpy(str,UpperLower(str));
			del(str);
		}
	}
	catch(FileNotFoundException e){
		cout<<e.str<<endl;
	}
	catch(NoRecordFoundException e){
		cout<<e.str<<endl;
	}
	getch();
}
//=========================================================================
void AddressBook::menuScreen(){
	char ch;
	do{
		system("clear");
		cout<<"		          :: ADDRESS BOOK::"<<endl;
		cout<<"A::Add"<<endl;
		cout<<"V::View"<<endl;
		cout<<"S::Search"<<endl;
		cout<<"s::Advance Search"<<endl;
		cout<<"e::Extreme Search"<<endl;
		cout<<"M::Modify"<<endl;
		cout<<"d::Delete record"<<endl;
		cout<<"F::Format The File"<<endl;
		cout<<"R::Remove A File"<<endl;
		cout<<"G::Goto Another File"<<endl;
		cout<<"E::Exit"<<endl;
		cout<<"Enter your choice : "<<endl;
		ch=getch();
		switch (ch){
			case 'A':
			case 'a':
				addition();
				break;
			case 'V':
			case 'v':
				display();
				break;
			case 's':
				advanceSearch();
				break;
			case 'S':
				search();
				break;
			case 'M':
			case 'm':
				modify();
				break;
			case 'D':
			case 'd':
				deletion();
				break;
			case 'F':
			case 'f':{
					ofstream obj;
					obj.open(directory);
					obj.close();
					cout<<"Formatted";
					//flush();
					getchar();
					break;
			}
			case 'e':
				extremeSearch();
				break;
			case 'G':
			case 'g':
				createFile();
				break;
			case 'E':
				return;
			case 'r':
			case 'R':
				cout<<"Enter the file name : ";
				char rem[30];
				cin.getline(rem,30);
				remove(rem);
				break;
			default:
				cout<<"Wrong Choice"<<endl;
		}
	}while(ch!='E'||ch!='e');
}
//=========================================================================
void AddressBook::welcomeScreen(){
	system("clear");
	cout<<"+++++++++++++++++++++++++++++++++++++++++++++++++++++++++"<<endl;
	cout<<"		           ADDRESS BOOK"<<endl;
	cout<<"+++++++++++++++++++++++++++++++++++++++++++++++++++++++++"<<endl;
	cout<<"\n\n\n\nPress any key to continue................";
	getch();
}
//=========================================================================
int main(){
	AddressBook T;
	try{
		T.createFile();
		T.welcomeScreen();
//		T.init();
		T.menuScreen();
	}
	catch(Exception e){
		e.str;
	}
	return 0;
}
