//exceptions.cc
#include<string.h>
class Exception{
public:
	char str[40];
	Exception (const char *p){
		strcpy(str,p);
	}
};
//=================================
class InvalidMobileException{
public:
	char str[25];
	InvalidMobileException(){
		strcpy(str,"Invalid Mobile Number");
	}
};
//=================================
class InvalidLandlineException{
public:
	char str[25];
	InvalidLandlineException(){
		strcpy(str,"Invalid Landline Number");
	}
};
//=================================
class InvalidEmailException{
public:
char str[25];
	InvalidEmailException(){
		strcpy(str,"Invalid Email id");
	}
};	
//=================================
class FileNotFoundException{
public:
	char str[25];
	FileNotFoundException(){
		strcpy(str,"File not found or it can't be opened");
	}
};
//=================================
class NoRecordFoundException{
public:
	char str[25];
	NoRecordFoundException(){
		strcpy(str,"No Record Found");
	}
};
