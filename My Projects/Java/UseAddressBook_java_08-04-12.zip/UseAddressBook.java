import java.io.*;
import java.util.*;
import static java.lang.System.out;

class InvalidMobileException extends Exception{
	public InvalidMobileException(){
		super("Invalid Mobile Number");
	}
}
class InvalidLandlineException extends Exception{
	public InvalidLandlineException(){
		super("Invalid Landline Number");
	}
}
class InvalidEmailException extends Exception{
	public InvalidEmailException(){
		super("Invalid Email id");
	}
}
class OtherException extends Exception{
	public OtherException(String msg){
		super(msg);
	}
}
class StringUtils{
	public static String UpperLower(String S){
		S=S.trim();
		int i,j,k;
		int []pos=new int[10];
		pos[0]=0;
		for(i=1,j=1;i<S.length();i++){
			if(S.charAt(i)==' ')
				pos[j++]=i+1;
		}
		StringBuffer S1=new StringBuffer(S.length());
		S1.append(S);
		for(k=0;k<=j-1;k++)
			S1.replace(pos[k],pos[k]+1,(S.charAt(pos[k])+"").toUpperCase());
		return (new String(S1));
	}
//======================================================================
	public static String[] GetCombinations(String S){
		S=S.trim();
		StringBuffer []S1=new StringBuffer[4];
		for(int i=0;i<4;i++){
			S1[i]=new StringBuffer(S.length());
			S1[i].append(S);
		}
		
		S1[0].replace(0,S.length()+1,S.toLowerCase());
		S1[1].replace(0,1,(S.charAt(0)+"").toUpperCase());
		S1[2].replace(0,S.length()+1,UpperLower(S));
		S1[3].replace(0,S.length()+1,S.toUpperCase());
		
		String S2[]=new String [4];
		for(int i=0;i<4;i++){
			S2[i]=new String(S1[i]);
		}
		return (S2);
	}
//======================================================================
	public static boolean IsValidNumber(String S){
		for(int i=0;i<S.length();i++){
			if((S.charAt(i)<'0')||((S.charAt(i)>'9')))
				return false;
		}
		return true;
	}
//======================================================================
	public static boolean IsValidMobile(String S){
		if(S.length()!=10)
			return false;
		for(int i=0;i<S.length();i++){
			if((S.charAt(i)<'0')||((S.charAt(i)>'9')))
				return false;
		}
		return true;
	}
//======================================================================
	public static int Strcmp(String S1, String S2){
		if(S1.equalsIgnoreCase(S2))
			return 0;
		if((S1.length()>S2.length())&&S1.startsWith(S2.toLowerCase())==true)
			return 1;
		else
			return -1;
	}
//======================================================================
	public static boolean StrcmpAdv(long ph1, long ph2){
		String S1=String.valueOf(ph1);
		String S2=String.valueOf(ph2);
		if(S1.indexOf(S2)==-1)
			return false;
		else
			return true;
	}
//======================================================================
	public static boolean StrcmpAdv(String S1, String S2){
		if((S1.toLowerCase()).indexOf(S2.toLowerCase())==-1)
			return false;
		else
			return true;
	}
}
class AddressBook extends StringUtils{
	private long mobile,landline;
	private String name,email;
	public void menu(){
		out.println("		          :: ADDRESS BOOK::");
		out.println("A::Add");
		out.println("V::View");
		out.println("S::Search");
		out.println("M::Modify");
		out.println("D::Deletion");
		out.println("R::Remove File");
		out.println("F::Format File");
		out.println("G::Goto Another File");
		out.println("E::Exit");
		out.println("Enter your choice");
		
		String S;
		Scanner kb=new Scanner(System.in);
		do{
			S=kb.next();			
			switch (S.charAt(0)){
				case 'A':
				case 'a':
					addition();
					break;
				case 'V':
				case 'v':
					display();
					break;
				case 'M':
				case 'm':
					modify();
					break;
				case 'D':
				case 'd':
					deletion();
					break;
				case 'F':
				case 'f':{
					/*	ofstream obj;
						obj.open(directory);
						obj.close();
						cout<<"Formatted";
						*/break;
						}
				case 'S':
				case 's':
					search();
				break;
				case 'G':
				case 'g':
					createFile();
					break;
				case 'E':
					System.exit(0);
				case 'r':
				case 'R':
					out.print("Enter the file name : ");
					String temp=kb.nextLine();
					break;
				default:
					out.println("Wrong Choice");
			}
		}while(S.equalsIgnoreCase("e")==false);
}
public void addition(){
}
public void display(){
}
public void modify(){
}
public void deletion(){
}
public void search(){
}
public void createFile(){
}
}
class UseAddressBook{
	public static void main(String args[]){
	}
}
