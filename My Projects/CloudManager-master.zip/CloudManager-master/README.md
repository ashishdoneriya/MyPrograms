# CloudManager
node.js based cloud manager
