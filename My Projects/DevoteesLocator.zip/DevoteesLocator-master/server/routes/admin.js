const express = require('express');
const router = express.Router();
const connection = require('../database/mysql_connector');

// Sending Logged in user information
router.get('/admin-info', (req, res) => {
	// @ts-ignore
	var userId = req.session.userId;
	if (!userId) {
		res.status(403).send('You need to log in').end();
	} else {
		connection.query('SELECT userId, name, email from users where userId=?', [userId], function (error, results, fields) {
			if (error) {
				console.error('Error while fetching information', error);
				res.status(500).send(error).end();
			} else {
				res.status(200).send(results[0]).end();
			}
		});
	}
});

// Updating Logged in user information
router.post('/admin-info', (req, res) => {
	// @ts-ignore
	var userId = req.session.userId;
	var name = req.body.name;
	var email = req.body.email;
	var password = req.body.password;
	if (!userId) {
		res.status(403).send('You need to log in').end();
	} else {
		connection.query('UPDATE users SET name=? and email=? and password=? where userId=?', [name, email, password, userId], function (error, results, fields) {
			if (error) {
				console.error('Error while fetching information', error);
				res.status(500).send(error).end();
			} else {
				res.status(200).send('success').end();
			}
		});
	}
});

// Updating Logged in user information
router.post('/add-table', (req, res) => {
	// @ts-ignore
	var userId = req.session.userId;
	var obj = req.body;
	var tableName = obj.tableName;
	var tableId = userId + '_' + tableName.toLowerCase().replace(/ /g, '_');
	var fields = obj.fields;
	if (!userId) {
		res.status(403).send('You need to log in').end();
	} else {
		for (var field of fields) {
			field.fieldId = field.fieldName.toLowerCase().replace(/ /g, '_');
		}
		var temp = fields;
		connection.query('INSERT INTO users_tables VALUES (?, ?, ?, ?)', [userId, tableId, tableName, JSON.stringify(fields)], function (error, results, fields) {
			if (error) {
				console.error('Error while fetching information', error);
				res.status(500).send(error).end();
			} else {
				createTable(tableId, temp, res);
			}
		});
	}
});

function createTable(tableId, fields, res) {

	for (var field of fields) {
		field.fieldId = field.fieldName.toLowerCase().replace(/ /g, '_');
	}
	var str = `CREATE TABLE ${tableId} (id int NOT NULL,`;


	for (var i = 0; i < fields.length; i++) {
		str += fields[i].fieldId + ' ' + getMysqlTypeField(fields[i].fieldType);
		if (i != fields.length - 1) {
			str += ', ';
		} else {
			str += ',  PRIMARY KEY (id));'
		}
	}
	connection.query(str, function (error, results, f) {
		if (error) {
			console.error('Error while creating table', error);
			res.status(500).send(error).end();
		} else {
			res.status(200).send('success').end();
		}
	});
}

function getMysqlTypeField(fieldType) {
	if (fieldType == 'string') {
		return 'MEDIUMTEXT';
	} else if (fieldType == 'number') {
		return 'INT(200)';
	}
}

router.post('/update-table', (req, res) => {
	// @ts-ignore
	var userId = req.session.userId;
	var table = req.body;
	var tableId = table.tableId;
	if (!userId) {
		res.status(403).send('You need to log in').end();
		return;
	}
	// @ts-ignore
	connection.query('SELECT fields FROM users_tables WHERE userId=? and tableId=?', [req.session.userId, tableId], function (error, results, temp) {
		if (error) {
			console.error('Error while updating information', error);
			res.status(500).send(error).end();
		} else {
			var oldFields = results[0].fields;
			for (var field of table.fields) {
				if (field.fieldId == null || field.fieldId == undefined || field.fieldId.trim() == '') {
					field.fieldId = field.fieldName.toLowerCase().replace(/ /g, '_');
					// ADDING FIELDS
					connection.query(`ALTER TABLE ${tableId} ADD ${field.fieldId} ${getMysqlTypeField(field.fieldType)}`);
				} else {
					// MODIFYING EXISTING FIELDS
					connection.query(`ALTER TABLE ${tableId} MODIFY COLUMN ${field.fieldId} ${getMysqlTypeField(field.fieldType)}`);
				}
			}
			for (var i = 0; i < oldFields.length; i++) {
				var fields = oldFields[i];
				var isExists = false;
				for (var temp1 of table.fields) {
					if (field.fieldId == temp1.fieldId) {
						isExists = true;
						break;
					}
				}
				if (!isExists) {
					// DELETING FIELDS
					connection.query(`ALTER TABLE ${tableId} DROP COLUMN ${field.fieldId}`);
				}
			}
			connection.query('UPDATE users_tables SET tableName=?, fields=? where userId=? and tableId=?', [table.tableName, JSON.stringify(table.fields), userId, table.tableId], function (error, results, fields) {
				if (error) {
					console.error('Error while updating information', error);
					res.status(500).send(error).end();
				} else {
					res.status(200).send('success').end();
				}
			});

		}
	});
});

router.get('/tables-list', (req, res) => {
	// @ts-ignore
	connection.query('SELECT tableId, tableName FROM users_tables WHERE userId=?', [req.session.userId], function (error, results, fields) {
		if (error) {
			console.error('Error while fetching information', error);
			res.status(500).send(error).end();
		} else {
			res.status(200).send(results).end();
		}
	});
});

router.post('/delete-table', (req, res) => {
	// @ts-ignore
	var userId = req.session.userId;
	var tableId = req.body.tableId;
	if (!userId) {
		res.status(403).send('You need to log in').end();
	} else {
		connection.query('DELETE FROM users_tables WHERE userId=? AND tableId=?', [userId, tableId], function (error, results, fields) {
			if (error) {
				console.error('Error while fetching information', error);
				res.status(500).send(error).end();
			} else {
				res.status(200).send('success').end();
			}
		});
	}
});

router.get('/table-fields', (req, res) => {
	// @ts-ignore
	connection.query('SELECT fields FROM users_tables WHERE userId=? and tableId=?', [req.session.userId, req.query.tableId], function (error, results, fields) {
		if (error) {
			console.error('Error while fetching information', error);
			res.status(500).send(error).end();
		} else {
			res.status(200).send(results[0].fields).end();
		}
	});
});

router.get('/search-record', (req, res) => {
	var body = req.query;
	var tableId = body.tableId;
	var searchQuery = body.searchQuery;
	var pageNumber = body.pageNumber;
	var maximumResults = body.maximumResults;
	var sortBy = body.sortBy;
	var order = body.order;
	var isNumber = !isNaN(searchQuery);

	var fieldsQuery = `SELECT fields FROM users_tables WHERE tableId='${tableId}'`;

	// Getting field names to fetch
	connection.query(fieldsQuery, [], function (error1, results1, f1) {
		if (error1) {
			console.error('Error while fetching information', error1);
			res.status(500).send(error1).end();
			return;
		}
		var fields = JSON.parse(results1[0].fields);
		var whereQuery;

		// createing where query part
		if (searchQuery) {
			whereQuery = 'where ';
			for (var i = 0; i < fields.length; i++) {
				var field = fields[i];

				if (field == null) {
					continue;
				}
				if (field.fieldType == 'string') {
					whereQuery += field.fieldId + ` like '%${searchQuery}%' `;
				} else if (field.fieldType == 'number' && isNumber) {
					whereQuery += field.fieldId + '=' + searchQuery;
				}
				if (i != fields.length - 1) {
					whereQuery += 'OR ';
				}
			}
		}

		var countQuery = `select count(*) from ${tableId} ` + whereQuery;

		// Fetching number of rows
		connection.query(countQuery, [], function (error2, results2, f2) {
			if (error2) {
				console.error('Error while fetching information', error2);
				res.status(500).send(error2).end();
				return;
			}
			var totalRows = results2;
			var resultFetchQuery = `select * from ${tableId}`;
			if (whereQuery) {
				resultFetchQuery += ` ${whereQuery}`;
			}
			if (sortBy && order) {
				if (order == 'descending') {
					order = 'DESC';
				} else {
					order = 'ASC';
				}
				resultFetchQuery += ` order by ${sortBy} ${order}`;
			}
			if (pageNumber && maximumResults) {
				var startRow = (pageNumber - 1) * maximumResults;
				resultFetchQuery += ` LIMIT ${startRow}, ${maximumResults}`;
			}

			// Fetching records i.e. performing search operation
			connection.query(resultFetchQuery, [], function (error3, results3, f3) {
				if (error3) {
					console.error('Error while fetching information', error3);
					res.status(500).send(error3).end();
					return;
				}
				var obj = {
					totalResults: totalRows[0]["count(*)"],
					recordsList: results3
				};
				res.status(200).send(obj).end();
			});
		});
	});
});

module.exports = router;