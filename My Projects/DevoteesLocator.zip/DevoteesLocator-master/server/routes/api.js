const express = require('express');
const crypto = require('crypto');
const connection = require('../database/mysql_connector');

const router = express.Router();
var md5sum = crypto.createHash('md5');

router.post('/login', (req, res) => {
	var email = req.body.email;
	var password = req.body.password;
	if (!(email && password)) {
		res.status(200).send("Email or password can't be empty").end();
		return;
	}
	connection.query('select * from users where email=?', [email], function (error, results, fields) {
		if (error) {
			console.error('Error while checking login data', error);
			res.status(500).send(error).end();
		} else if (results.length == 0) {
			res.status(200).send('Email Id is not registered.').end();
		} else if (results[0].password != password) {
			res.status(200).send('Wrong password').end();
		} else {
			req.session.userId = results[0].userId;
			req.session.name = results[0].name;
			req.session.email = email;
			res.status(200).send('success').end();
		}
	});
});

router.post('/logout', (req, res) => {
	// @ts-ignore
	req.session.email = null;
	req.session.name = null;
	req.session.userId = null;
	res.status(200).send('success').end();
});

router.post('/register', (req, res) => {
	var name = req.body.name;
	var email = req.body.email;
	var password = req.body.password;

	if (!(name && email && password)) {
		res.status(401).send('Something missing').end();
		return;
	}

	connection.query("SELECT * from users where email=?", [email], function (error, results, fields) {
		if (error) {
			console.error('Error while registering user', error);
			res.status(500).send(error).end();
		} else {
			if (results.length > 0) {
				res.status(200).send('Email address ' + email + ' already registered').end();
			} else {
				connection.query("INSERT INTO users (`name`, `email`, `password`) VALUES (?, ?, ?)", [name, email, password], function (error, results, fields) {
					if (error) {
						console.error('Error while registering user', error);
						res.status(500).send(error).end();
					} else {
						res.status(200).send('success').end();
					}
				});
			}
		}
	});


});

module.exports = router;