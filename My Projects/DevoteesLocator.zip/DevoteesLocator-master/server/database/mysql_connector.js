var mysql = require('mysql');

var connection = mysql.createConnection({
	host: 'localhost',
	user: 'root',
	password: 'root',
	database: 'locator'
});

connection.connect();

// Creating table 'users' which contains users list
connection.query('CREATE TABLE IF NOT EXISTS users(\
userId INT PRIMARY KEY AUTO_INCREMENT,\
name VARCHAR(100) NOT NULL,\
email VARCHAR(100) NOT NULL,\
password VARCHAR(100) NOT NULL);');

// Creating table 'users_tables' which contains list of table names created by user.
//TODO if user deleted then its tables should also be deleted
//TODO add a field isPublic
connection.query('CREATE TABLE IF NOT EXISTS users_tables(\
			userId INT NOT NULL, \
			tableId VARCHAR(200) NOT NULL, \
			tableName VARCHAR(200) NOT NULL, \
			fields MEDIUMTEXT NOT NULL, \
			FOREIGN KEY (userId) REFERENCES users(userId));');

module.exports = connection;
