import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material';
import { Router } from '@angular/router';

import { ToastyConfig, ToastData, ToastOptions, ToastyService } from 'ng2-toasty'

import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';

import "rxjs/add/operator/debounceTime";
import "rxjs/add/operator/distinctUntilChanged";
import "rxjs/add/operator/switchMap";

import { ApiService } from '../../api.service';
import { Field } from '../field';
import { Table } from '../table';
import { TableFormComponent } from '../table-form/table-form.component';

@Component({
	selector: 'app-admin-dashboard',
	templateUrl: './admin-dashboard.component.html',
	styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {

	tablesList: any;

	toastOptions: ToastOptions;

	constructor(private apiService: ApiService,
		private dialog: MatDialog,
		private router: Router,
		private toastyConfig: ToastyConfig,
		private toastyService: ToastyService) { }

	ngOnInit() {
		this.toastyConfig.theme = 'material';
		this.toastOptions = {
			title: '',
			msg: '',
			showClose: true,
			timeout: 3000
		};
		this.updateTablesList();
	}

	private updateTablesList() {
		this.apiService.getTablesList().subscribe(data => {
			this.tablesList = data.json();
			console.log();
		}, error => {
			console.log(error);
		})
	}

    addTable() {
        this.router.navigate(['admin/form-builder']);
		// let dialogRef = this.dialog.open(TableFormComponent, {
		// 	height: '600px',
		// 	width: '900px',
		// });
		// dialogRef.afterClosed().subscribe(result => {
		// 	if (result == '') {
		// 		return;
		// 	}
		// 	this.apiService.addTable(result).subscribe(message => {
		// 		this.updateTablesList();
		// 		this.toastOptions.title = 'Table Added';
		// 		this.toastOptions.msg = '';
		// 		this.toastyService.success(this.toastOptions);
		// 	}, error => {
		// 		this.toastOptions.title = '';
		// 		this.toastOptions.msg = 'Unable to add the table.';
		// 		this.toastyService.error(this.toastOptions);
		// 	});
		// });
	}

	deleteTable(tableId: string) {
		this.apiService.deleteTable(tableId).subscribe(message => {
			this.updateTablesList();
			this.toastOptions.title = 'Table has been removed';
			this.toastOptions.msg = '';
			this.toastyService.success(this.toastOptions);
		}, error => {
			this.toastOptions.title = '';
			this.toastOptions.msg = 'Unable to remove the table.';
			this.toastyService.error(this.toastOptions);
		});
	}

	editTable(table: any) {
		let tableName = table.tableName;
		let tableId = table.tableId;
		this.apiService.getTableFields(tableId).subscribe(data => {
			let temp: Table = new Table(table.tableName, table.tableId, data.json());
			this.openTableForm(temp);
		}, error => {
			console.log(error);
		})
	}

	private openTableForm(table: Table) {
		let dialogRef = this.dialog.open(TableFormComponent, {
			height: '600px',
			width: '900px',
			data: table
		});
		dialogRef.afterClosed().subscribe(result => {
			if (result == '') {
				return;
			}
			console.log(result);
			this.apiService.updateTable(result).subscribe(message => {
				this.updateTablesList();
				this.toastOptions.title = 'Table Modified';
				this.toastOptions.msg = '';
				this.toastyService.success(this.toastOptions);
			}, error => {
				this.toastOptions.title = '';
				this.toastOptions.msg = 'Unable to modify the table.';
				this.toastyService.error(this.toastOptions);
			});
		});
	}

}
