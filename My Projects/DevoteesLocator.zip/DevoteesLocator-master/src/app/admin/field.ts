export class Field {
	fieldNumber: number;
	fieldName: string;
	fieldId: string;
	fieldType: string;
	isSelected: boolean;

	constructor(fieldNumber: number) {
		this.fieldNumber = fieldNumber;
		this.fieldName = '';
		this.fieldId = '';
		this.fieldType = '';
	}
}
