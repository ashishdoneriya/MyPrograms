import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material';
import { Router } from '@angular/router';

import { ToastyConfig, ToastData, ToastOptions, ToastyService } from 'ng2-toasty'

import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';

import "rxjs/add/operator/debounceTime";
import "rxjs/add/operator/distinctUntilChanged";
import "rxjs/add/operator/switchMap";

import { ApiService } from '../api.service';
import { Field } from './field';
import { Table } from './table';
import { TableFormComponent } from './table-form/table-form.component';

@Component({
	selector: 'app-admin',
	templateUrl: './admin.component.html',
	styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

	tablesList: any;

	private toastOptions: ToastOptions;

	selectedTable: string;

	constructor(
		private apiService: ApiService,
		private dialog: MatDialog,
		private router: Router,
		private toastyConfig: ToastyConfig,
		private toastyService: ToastyService) { }

	ngOnInit() {
		this.updateTablesList();
	}

	private updateTablesList() {
        this.apiService.getTablesList().subscribe(data => {
            this.tablesList = data.json();
            console.log();
        }, error => {
            console.log(error);
        });
	}

	showTable() {
		this.router.navigate(['/admin/table', this.selectedTable]);
	}

}
