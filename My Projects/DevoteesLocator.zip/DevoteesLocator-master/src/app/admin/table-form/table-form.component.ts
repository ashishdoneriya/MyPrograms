import { Component, Inject, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA  } from '@angular/material';
import { Field } from '../field';
import { Table } from '../table';
@Component({
	selector: 'table-form',
	templateUrl: './table-form.component.html',
	styleUrls: ['./table-form.component.css']
})
export class TableFormComponent implements OnInit {

	tableForm: FormGroup;

	heading: string;

	count: number = 0;

	tableId: string;

	fieldTypes = [
		{ value: 'string', viewValue: 'String' },
		{ value: 'number', viewValue: 'Number' }
	];

	constructor(
		public dialog: MatDialogRef<TableFormComponent>,
		@Inject(MAT_DIALOG_DATA ) public table: Table,
		private fb: FormBuilder) {
		if (table && table.tableId) {
			this.tableId = table.tableId;
			this.heading = 'Modify Table';
			this.tableForm = this.fb.group({
				tableName: table.tableName,
				fields: this.fb.array([])
			});
			for (let field of table.fields) {
				this.fields.push(this.fb.group(field));
				this.count++;
			}
		} else {
			this.heading = 'Add Table';
			this.tableForm = this.fb.group({
				tableName: '',
				fields: this.fb.array([])
			});
			this.fields.push(this.fb.group(new Field(++this.count)));
		}
	}

	ngOnInit() {
	}

	addField() {
		this.fields.push(this.fb.group(new Field(++this.count)));
	}

	removeField(i: number) {
		this.fields.removeAt(i);
	}

	shiftUp(i: number) {
		if (i == 0) {
			return;
		}
		let field = this.fields.at(i);
		this.fields.removeAt(i);
		this.fields.insert(i - 1, field);
	}

	shiftDown(i: number) {
		if (i == this.fields.length - 1) {
			return;
		}
		let field = this.fields.at(i);
		this.fields.removeAt(i);
		this.fields.insert(i + 1, field);
	}

	get fields(): FormArray {
		return this.tableForm.get('fields') as FormArray;
	};

	save() {
		let fields: Array<Field> = this.fields.value;
		let x: number = 1;
		for (let field of fields) {
			field.fieldNumber = x++;
		}
		let table = new Table(this.tableForm.get('tableName').value,this.tableId, fields);
		this.dialog.close(table);
	}

}
