import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
	selector: 'app-form-builder',
	templateUrl: './form-builder.component.html',
	styleUrls: ['./form-builder.component.css']
})
export class FormBuilderComponent implements OnInit {

	fields = [];

	tableName = '';

	constructor(private route: ActivatedRoute,
		private router: Router) { }

	ngOnInit() {
	}

	goBack() {
		this.router.navigate(['admin/dashboard']);
	}

	save() {

	}

	addTextInput() {
		this.fields.push({
			fieldName: '',
			fieldType: 'textinput'
		});
	}

	addTextArea() {
		this.fields.push({
			fieldName: '',
			fieldType: 'textarea'
		});
	}

	addCheckbox() {
		this.fields.push({
			fieldName: '',
			fieldType: 'checkbox',
			options: []
		});
	}

	addRadio() {
		this.fields.push({
			fieldName: '',
			fieldType: 'radio',
			options: []
		});
	}

	addSelect() {
		this.fields.push({
			fieldName: '',
			fieldType: 'select',
			options: []
		});
	}

	deleteField(i: number) {
		this.fields.splice(i, 1);
	}

	shiftUp(i: number) {
		if (i == 0) {
			return;
		}
		let temp = this.fields[i - 1];
		this.fields[i - 1] = this.fields[i];
		this.fields[i] = temp;
	}

	shiftDown(i: number) {
		if (i == this.fields.length - 1) {
			return;
		}
		let temp = this.fields[i + 1];
		this.fields[i + 1] = this.fields[i];
		this.fields[i] = temp;
	}

	addOption(field) {
		field.options.push({
			value: ''
		});
	}

	removeOption(field, i) {
		field.options.splice(i, 1);
	}

	shiftOptionUp(field, i: number) {
		if (i == 0) {
			return;
		}
		let temp = field.options[i - 1];
		field.options[i - 1] = field.options[i];
		field.options[i] = temp;
	}

	shiftOptionDown(field, i: number) {
		if (i == field.options.length - 1) {
			return;
		}
		let temp = field.options[i + 1];
		field.options[i + 1] = field.options[i];
		field.options[i] = temp;
	}

}
