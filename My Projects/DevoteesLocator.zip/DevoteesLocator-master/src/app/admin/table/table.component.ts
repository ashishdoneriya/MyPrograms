import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MatDialog } from '@angular/material';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import "rxjs/add/operator/debounceTime";
import "rxjs/add/operator/distinctUntilChanged";
import "rxjs/add/operator/switchMap";
import { ToastyConfig, ToastData, ToastOptions, ToastyService } from 'ng2-toasty';

import { ApiService } from '../../api.service';
import { Field } from '../field';
import { Table } from '../table';

@Component({
	selector: 'app-table',
	templateUrl: './table.component.html',
	styleUrls: ['./table.component.css']
})
export class TableComponent implements OnInit {

	tableId: string;
	columnsList: Array<Field>;
	recordsList: Array<any>;
	searchQuery: string = '';
	currentPageNo: number = 1;
	totalResults: number = 0;
	maximumResults: number = 10;
	sortBy: string = '';
	order: string = 'ascending';

	cSerialNumber: boolean = true;
	cActions: boolean = true;

	private searchTermStream = new Subject<string>();
	private toastOptions: ToastOptions;

	constructor(private apiService: ApiService,
		private route: ActivatedRoute,
		private router: Router,
		private toastyService: ToastyService,
		private toastyConfig: ToastyConfig, ) { }

	ngOnInit() {
		this.toastyConfig.theme = 'material';
		this.toastOptions = {
			title: '',
			msg: '',
			showClose: true,
			timeout: 3000
		};

		this.route.params.subscribe(params =>
			this.tableId = params['tableId']
		);
		this.apiService.getTableFields(this.tableId).subscribe(data => {
			this.columnsList = data.json();
			for (let column of this.columnsList) {
				column.isSelected = true;
			}
		}, error => {
			console.log(error);
		});

		this.searchTermStream
			.debounceTime(300)
			.distinctUntilChanged().subscribe((term: string) => {
				this.currentPageNo = 1;
				this.search();
			});
		this.search();
	}

	update(query: string) {
		this.searchTermStream.next(query);
	}

	search(pageNumber?: number) {
		this.apiService.searchRecord(this.tableId, this.searchQuery, this.currentPageNo, this.maximumResults, this.sortBy, this.order).subscribe(data => {
			let obj = data.json();
			this.totalResults = obj.totalResults;
			this.recordsList = obj.recordsList;
		}, error => {
			this.toastOptions.title = '';
			this.toastOptions.msg = 'Unable to fetch data.';
			this.toastyService.error(this.toastOptions);
		});
	}

	updateSortOrder(fieldId: string) {
		if (this.sortBy == fieldId) {
			if (this.order == 'ascending') {
				this.order = 'descending';
			} else {
				this.order = 'ascending';
			}
		} else {
			this.sortBy = fieldId;
			this.order = 'ascending';
		}
		this.search();
	}

	addRow() {

	}

	editRow(row) {

	}

	deleteRow(id: number) {

	}

}
