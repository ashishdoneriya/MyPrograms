import { Field } from './field';

export class Table {
	tableName: string;
	tableId: string;
	fields: Array<Field>;

	constructor(tableName?:string, tableId?:string, fields?: Array<Field>) {
		this.tableName = tableName || '';
		this.tableId = tableId || '';
		this.fields = fields || [];
	}
}