import { Injectable } from '@angular/core';
import { Headers, Http, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Observer } from 'rxjs';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

import { Field } from './admin/field';
import { Table } from './admin/table';
@Injectable()
export class ApiService {

	constructor(private http: Http) { }

	login(email:string, password: string) {
		let params: URLSearchParams = new URLSearchParams();
		params.set("email", email);
		params.set("password", password);
		let body = params.toString()

		var headers = new Headers();
		headers.append('Content-Type', 'application/x-www-form-urlencoded');
		return this.http.post('/api/login', body, {
			headers: headers
		}).map(this.extractBody);
	}

	logout() {
		this.http.post('/api/logout', {});
	}

	register(name:string, email:string, password: string) {
		let params: URLSearchParams = new URLSearchParams();
		params.set('name', name);
		params.set('email', email);
		params.set('password', password);
		let body = params.toString()

		var headers = new Headers();
		headers.append('Content-Type', 'application/x-www-form-urlencoded');
		return this.http.post('/api/register', body, {
			headers: headers
		}).map(this.extractBody);
	}

	addTable(table :Table) {
		var headers = new Headers();
		headers.append('Content-Type', 'application/json');

		return this.http.post('/api/admin/add-table', JSON.stringify(table), {
			headers: headers
		}).map(this.extractBody);
	}

	updateTable(table :Table) {
		var headers = new Headers();
		headers.append('Content-Type', 'application/json');

		return this.http.post('/api/admin/update-table', JSON.stringify(table), {
			headers: headers
		}).map(this.extractBody);
	}

	getLoggedInUserInfo() {
		return this.http.get('/api/admin/admin-info').map(this.extractBody);
	}

	updateLoggedInUserInfo(data:any) {
		return this.http.post('/api/admin/admin-info', data).map(this.extractBody);
	}

	getTablesList() {
		return this.http.get('/api/admin/tables-list');
	}

	getTableFields(tableId: string) {
		let params: URLSearchParams = new URLSearchParams();
		params.set("tableId", tableId);
		return this.http.get('/api/admin/table-fields', { search: params });
	}

	deleteTable(tableId:string) {
		let params: URLSearchParams = new URLSearchParams();
		params.set('tableId', tableId);
		let body = params.toString()

		var headers = new Headers();
		headers.append('Content-Type', 'application/x-www-form-urlencoded');
		return this.http.post('/api/admin/delete-table', body, {
			headers: headers
		}).map(this.extractBody);
	}

	searchRecord(tableId: string, searchQuery?: string, pageNumber?: any, maximumResults?: any, sortBy?: any, order?: any) {
		//TODO make order enum type ASC / DESC
		let params: URLSearchParams = new URLSearchParams();
		params.set("tableId", tableId);
		if (searchQuery) {
			params.set("searchQuery", searchQuery);
		}
		if (pageNumber) {
			params.set('pageNumber', pageNumber);
		}
		if (maximumResults) {
			params.set('maximumResults', maximumResults);
		}
		if (sortBy) {
			params.set('sortBy', sortBy);
		}
		if (order) {
			params.set('order', order);
		}
		return this.http.get('/api/admin/search-record', { search: params });
	}

	deleteRecord(tableId: number) {
		return this.http.delete('/api/admin/record?recordId=' + tableId)
			.map((res: Response) => res.text);
	}

	download(searchQuery: string, sortBy: any, order: any, selectedColumns: Array<string>) {
		let params: URLSearchParams = new URLSearchParams();
		if (searchQuery) {
			params.set("searchQuery", searchQuery);
		}
		if (sortBy) {
			params.set('sortBy', sortBy);
		}
		if (order) {
			params.set('order', order);
		}
		if (selectedColumns) {
			params.set("selectedColumns", JSON.stringify(selectedColumns));
		}
		return this.http.get('/apis/devotees/download', { search: params });
	}

	upload(file: File) {
		return Observable.create((observer: Observer<any>) => {
			let formData: FormData = new FormData();
			formData.append('file', file);
			let xhr = new XMLHttpRequest();
			xhr.onreadystatechange = function () {
				if (xhr.readyState === 4) {
					if (xhr.status === 200) {
						observer.complete();
					} else {
						observer.error(xhr.response);
					}
				}
			}
			xhr.open('POST', '/apis/upload', true);
			xhr.send(formData);
		});
	}

	private extractData(res: Response) {
		let body = res.json();
		return body.data || null;
	}

	private extractBody(res: any) {
		return res._body;
	}

	private handleError(error: Response | any) {
		// In a real world app, we might use a remote logging infrastructure
		let errMsg: string;
		if (error instanceof Response) {
			const body = error.json() || '';
			const err = body.error || JSON.stringify(body);
			errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
		} else {
			errMsg = error.message ? error.message : error.toString();
		}
		console.error(errMsg);
		return Observable.throw(errMsg);
	}
}