import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule, JsonpModule } from '@angular/http';
import { RouterModule, Routes } from '@angular/router';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ToastyModule } from 'ng2-toasty';
import 'hammerjs';

import { AppComponent } from './app.component';
import { ApiService } from './api.service';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { AdminComponent } from './admin/admin.component';
import { TableFormComponent } from './admin/table-form/table-form.component';
import { TableComponent } from './admin/table/table.component';
import { AdminDashboardComponent } from './admin/admin-dashboard/admin-dashboard.component';
import { MaterialModule } from './material-module/material.module';
import { FormBuilderComponent } from './admin/form-builder/form-builder.component';

const appRoutes: Routes = [
	{ path: '', redirectTo: 'login', pathMatch: 'full' },
	{ path: 'login', component: LoginComponent },
	{ path: 'register', component: RegisterComponent },
	{
		path: 'admin',
		component: AdminComponent,
		children: [
			{ path: '', redirectTo: 'dashboard', pathMatch: 'full' },
			{ path: 'dashboard', component: AdminDashboardComponent },
            { path: 'table/:tableId', component: TableComponent },
            { path: 'form-builder', component: FormBuilderComponent }
		]
	}
]

@NgModule({
	declarations: [
		AppComponent,
		LoginComponent,
		RegisterComponent,
		AdminComponent,
		TableFormComponent,
		TableComponent,
		AdminDashboardComponent,
		FormBuilderComponent
	],
	imports: [
		BrowserModule,
		BrowserAnimationsModule,
		FormsModule,
		HttpModule,
		JsonpModule,
		MaterialModule,
		ReactiveFormsModule,
		NgbModule.forRoot(),
		RouterModule.forRoot(appRoutes),
		ToastyModule.forRoot()
	],
	providers: [ApiService],
	bootstrap: [AppComponent],
	entryComponents: [TableFormComponent],
	schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule { }
