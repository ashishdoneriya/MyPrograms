import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastyService, ToastyConfig, ToastOptions, ToastData } from 'ng2-toasty';
import { ApiService } from '../api.service';

@Component({
	selector: 'app-login',
	templateUrl: './login.component.html',
	styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

	email: string;
	password: string;
	toastOptions: ToastOptions;

	constructor(private router: Router,
		private apiService: ApiService,
		private toastyService: ToastyService,
		private toastyConfig: ToastyConfig) { }

	ngOnInit() {
		this.toastyConfig.theme = 'material';
		this.toastOptions = {
			title: '',
			msg: '',
			showClose: false,
			timeout: 2000
		};
		this.email = '';
		this.password = '';
	}

	login() {
		if (this.email.length == 0 && this.password.length == 0) {
			this.toastOptions.msg = 'Please fill your email id and password';
			this.toastyService.error(this.toastOptions);
			return;
		} else if (this.email.length == 0) {
			this.toastOptions.msg = 'Please fill your email id';
			this.toastyService.error(this.toastOptions);
			return;
		} else if (this.password.length == 0) {
			this.toastOptions.msg = 'Please fill your password';
			this.toastyService.error(this.toastOptions);
			return;
		}
		this.apiService.login(this.email, this.password).subscribe(
			result => {
				if (result == 'success') {
					this.router.navigate(['admin']);
				} else {
					this.toastOptions.msg = result;
					this.toastyService.error(this.toastOptions);
				}
			},
			error => {
				console.error('Error while checking login details.', error);
				this.toastOptions.msg = 'Error while checking login details';
				this.toastyService.error(this.toastOptions);
			}
		);
	}

	register() {
		this.router.navigate(['register']);
	}

}
