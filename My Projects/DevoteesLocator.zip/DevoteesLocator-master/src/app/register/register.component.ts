import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastyService, ToastyConfig, ToastOptions, ToastData } from 'ng2-toasty';
import { ApiService } from '../api.service';

@Component({
	selector: 'app-register',
	templateUrl: './register.component.html',
	styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

	name = '';
	email = '';
	password = '';
	password1 = '';
	toastOptions: ToastOptions;

	constructor(private router: Router,
		private apiService: ApiService,
		private toastyService: ToastyService,
		private toastyConfig: ToastyConfig) { }

	ngOnInit() {
		this.toastyConfig.theme = 'material';
		this.toastOptions = {
			title: '',
			showClose: false,
			timeout: 4000
		};
	}

	isEmpty(field: string) {
		return !field ? true : false;
	}

	register() {

		if (this.isEmpty(this.name)
			|| this.isEmpty(this.email)
			|| this.isEmpty(this.password)
			|| this.isEmpty(this.password1)) {
			this.toastOptions.msg = 'Please fill all the fields';
			this.toastyService.error(this.toastOptions);
			return;
		}
		if (this.password != this.password1) {
			this.toastOptions.msg = 'Password mismatch';
			this.toastyService.error(this.toastOptions);
			return;
		}

		this.apiService.register(this.name, this.email, this.password).subscribe(
			result => {
				if (result == 'success') {

					this.toastOptions.title = 'Registration Successful';
					this.toastOptions.msg = '';
					this.toastyService.success(this.toastOptions);
					setTimeout(() => {
						this.router.navigate(['login']);
					}, 4000);
				} else {
					this.toastOptions.title = '';
					this.toastOptions.msg = result;
					this.toastyService.error(this.toastOptions);
				}
			},
			error => console.log(error)
		);
	}

}