#include <stdio.h>

int main()
{
	char text[] = "Going! Going! Gone!";
	char *t;

/* initialize the pointer */
	t = text;
	
/* display the string */
	puts(*t);

	return(0);	
}

