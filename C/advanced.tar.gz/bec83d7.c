#include <stdio.h>

int main()
{
	printf("0xBEC83D7 is %d\n",0xBEC83D7);
	return(0);
}

