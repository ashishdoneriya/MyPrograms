#include <stdio.h>

int main()
{
	int value,v8,v2,total;

	printf("Enter an integer value: ");
	scanf("%d",&value);

/* First multiply by 8 */
	v8 = value << 3;

/* Next, multiply by 2 */
	v2 = value << 1;

/* Then add the values */
	total = v8 + v2;

	printf("%d * 10 = %d\n",value,total);
	
	return(0);
}

