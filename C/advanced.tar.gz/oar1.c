#include <stdio.h>

int main()
{
	int twos = 1;
	int x,r;
	unsigned short int v = 0;

	for(x=0;x<16;x++)
	{
		r = v | twos;
		printf("0x%04X | %5d = 0x%04X\n",v,twos,r);
		twos += twos;
	}
	return(0);
}

