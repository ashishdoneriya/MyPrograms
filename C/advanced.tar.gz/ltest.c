#include <stdio.h>

int main()
{
	int a,b,r;

	puts("Exclusive OR ^ Operator");
	printf("bit\t^\tbit =\tresult\n");
	a = b = 1;
	r = a^b;
	printf("%d\t^\t%d\t%d\n",a,b,r);
	a = 1; b = 0;
	r = a^b;
	printf("%d\t^\t%d\t%d\n",a,b,r);
	a = 0; b = 1;
	r = a^b;
	printf("%d\t^\t%d\t%d\n",a,b,r);
	a = b = 0;
	r = a^b;
	printf("%d\t^\t%d\t%d\n",a,b,r);

	return(0);
}
