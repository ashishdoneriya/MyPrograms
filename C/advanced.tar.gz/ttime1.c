#include <stdio.h>
#include <time.h>

int main()
{
	struct tm *t;
	time_t now;
	int hour,min,sec;
	char ap;

	time(&now);		/* get the current time */
	t = localtime(&now);	/* get the tm structure */

/* fill variables with time values */
	hour = t->tm_hour;
	min = t->tm_min;
	sec = t->tm_sec;

/* convert 12/24 time format */
	if(hour > 12)
	{
		hour -= 12;	/* subtract 12 from hour */
		ap = 'P';	/* PM */
	}
	else
		ap = 'A';	/* AM */
	
	printf("It is now %d:%02d:%02d %cM\n",
			hour,
			min,
			sec,
			ap);
	return(0);
}

