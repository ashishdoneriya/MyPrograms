#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main()
{
	char input[64];
	char *string;
	int size;

	printf("Enter some text: ");
	gets(input);
	size = strlen(input) + 1;	/* remember the NULL! */
	string = (char *)malloc(size);
	if(string==(char *)NULL)
	{
		puts("Not enough memory!");
		return(0);
	}

	strcpy(string,input);
	printf("Original string: %s\nDuplicate: %s\n",input,string);
	return(0);
}

