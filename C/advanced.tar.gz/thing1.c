#include <stdio.h>

int main()
{
	const char *hello = "Greetings from your computer!";
	char byebye[] = "So long now!";
	char *b;
	char f;

/* initialize the pointer */
	b = byebye;
	
	f = *(hello+10);
	printf("The 10th character is '%c'\n",f);	
	
	puts(hello);
	puts(b);
	return(0);	
}

