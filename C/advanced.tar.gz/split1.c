#include <stdio.h>

int main()
{
	unsigned long int hex,h1,h2,h3,h4;

	printf("Enter an eight-digit hex value: ");
	scanf("%x",&hex);

	h1 = hex & 0x000000FF;
	h2 = hex & 0x0000FF00;
	h3 = hex & 0x00FF0000;
	h4 = hex & 0xFF000000;
	h2 >>= 8;
	h3 >>= 16;
	h4 >>= 24;

	printf("0x%08X is composed of %02X %02X %02X %02X\n",
			hex,h4,h3,h2,h1);
	
	return(0);
}

