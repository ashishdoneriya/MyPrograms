#include <stdio.h>

int strlength(char *string);

int main()
{
	char input[64];
	int len;

	printf("Enter some text: ");
	gets(input);
	len = strlength(input);
	printf("That text is %d characters long.\n",len);
	return(0);
}

int strlength(char *string)
{
	int x = 0;

	while(*string++)
	{
		x++;
	}
	return(x);
}

