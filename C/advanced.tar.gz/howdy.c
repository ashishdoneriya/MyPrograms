#include <stdio.h>
#include <string.h>

int main()
{
	char *string;

	strcpy(string,"Howdy! Howdy! Hi!");
	printf("%s",string);
	return(0);
}

