#include <stdio.h>

int main()
{
	printf("Hello ");
	b();
	c(5);
	return(0);
}

