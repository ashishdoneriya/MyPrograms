#include <stdio.h>

int main()
{
	float duration;
	float distance = 378921.46;
	float speed = 140;
	float *d;

	duration = distance / speed;

	d = &distance;
	printf("The moon is %f km away.\n",*d);
	d = &speed;
	printf("Traveling at %f kph, ",*d);
	d = &duration;
	printf("it would take %f hours to drive to the moon.\n",*d);
	return(0);
}

