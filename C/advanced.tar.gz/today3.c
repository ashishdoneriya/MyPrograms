#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int main()
{
	time_t now;

	time(&now);
	printf("It is now %s\n",localtime(&now));
	return(0);
}

