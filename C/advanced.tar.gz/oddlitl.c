#include <stdio.h>

int main()
{
	char c;
	short int i;
	long x;
	float f;
	double d;

	printf("char variable c = %c\n",c);
	printf("int variable i = %d\n",i);
	printf("long variable x = %d\n",x);
	printf("float variable f = %f\n",f);
	printf("double variable d = %f\n",d);
	return(0);
}
