#include <stdio.h>

int age;

int main()
{
	printf("Enter your age in years: ");
	scanf("%d",&age);
	show();
	return(0);
}

