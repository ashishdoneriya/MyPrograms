#include <stdio.h>

int main()
{
	char array[] = "Hello!\n";
	char *a;
	int x;

	for(x=0;x<sizeof(array);x++)
	{
		a = &array[x];
		printf("array[%d] at %p = %c\n",x,a,array[x]);
	}
	return(0);
}
