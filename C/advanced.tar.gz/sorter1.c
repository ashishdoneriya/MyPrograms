#include <stdio.h>

#define SIZE 5

int main()
{
	int input[SIZE];
	int *isort[SIZE];
	int *temp;
	int x,a,b;

/* Get the SIZE number of integers */
	printf("Enter %d numbers:\n",SIZE);
	for(x=0;x<SIZE;x++)
	{
		printf("#%d: ",x+1);
		scanf("%d",&input[x]);
		isort[x] = &input[x];	/* get address, not value */
	}

/* Sort the values via pointers */
	for(a=0;a<SIZE-1;a++)
		for(b=a+1;b<SIZE;b++)
			if(*isort[a] > *isort[b])	/* values! */
			{
				temp = isort[a];
				isort[a] = isort[b];
				isort[b] = temp;
			}

/* print the results */
	printf("Sorted list:\tOriginal list:\n");
	for(x=0;x<SIZE;x++)
		printf("%12d\t%12d\n",*isort[x],input[x]);

	return(0);
}

