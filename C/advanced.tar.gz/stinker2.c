#include <stdio.h>

int main()
{
	char string[] = "Is it supposed to smell that way?";
	char *s;

/* Initialize pointer */
	s = string;
	
	while(*s)	/* NULL character ends string */
	{
		putchar(*s);
		s++;
	}	
	return(0);	
}

