#include <stdio.h>

void b(void)
{
	printf("World!\n");
}

