#include <stdio.h>

void c(int count)
{
	while(count--)
		puts("I'm having fun now");
}

