#include <stdio.h>

int main()
{
	int v,r;
	
	printf("Enter an integer value: ");
	scanf("%d",&v);
	r = v >> 2;	/* Shift bits two notches right */
	printf("%d cut in quarter is %d\n",v,r);
	return(0);
}

