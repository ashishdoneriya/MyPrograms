#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
	char *input;
	int size;

/* Allocate "enough" memory */
	input = (char *)malloc(4096);	/* 4K input buffer */
	
	printf("Enter some text: ");
	gets(input);
	
/* re-size input buffer to save space */
	size = strlen(input) + 1;	/* +1 for NULL */
	if(!realloc(input,size))
	{
		puts("Unable to reallocate memory");
		return(0);
	}
	puts("Memory reallocation successful");
	printf("String is:\n\"%s\"\n",input);
	return(0);
}

