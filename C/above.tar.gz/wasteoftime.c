#include <stdio.h>
#include <ctype.h>

int main()
{
	char input[128];
	int x,numbers;
	
	x = numbers = 0;
	
	printf("Enter your street address:");
	gets(input);

/* scan the text */
	while(input[x])
	{
		if(isdigit(input[x]))
			numbers++;
		x++;
	}
	printf("Your address has %d numbers in it.\n",numbers);
	return(0);
}

