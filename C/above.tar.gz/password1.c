#include <stdio.h>
#include <string.h>

int main()
{
	char string[16];
	char password[] = "please";

	printf("enter your secret password:");
	gets(string);

	if(!strcmp(string,password))
		puts("Entry granted!");
	else
		puts("Sorry. Wrong password!");
	return(0);
}

