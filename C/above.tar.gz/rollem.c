#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void line(int length);
int throw(void);

int main()
{
	int dice,x,roll;
	int total = 0;

/* seed randomizer */
	
	srand((unsigned)time(NULL));

/* Game title and prompt */
	puts("R O L L ' E M !");
	do
	{
		printf("How many dice would you like to roll (1 to 12)? ");
		scanf("%i",&dice);
	}
	while(dice < 1 || dice > 12);

	printf("Rolling %d...\nHere they come!\n",dice);

/* process / display */
	for(x=0;x<dice;x++)		/* first row */
		printf(" %2d ",x+1);
	putchar('\n');
	
	line(dice);			/* fancy line row */
	
	for(x=0;x<dice;x++)		/* third row */
	{
		roll = throw();
		total += roll;
		printf("| %d ",roll);
	}
	printf("|\n");

	line(dice);			/* fancy line row last */

	printf("Total = %d\n",total);
	
	return(0);
}

int throw(void)
{
	int die;

	die = rand() % 6 + 1;
	return(die);
}

void line(int length)
{
	int x;

	for(x=0;x<length;x++)
		printf("+---");
	printf("+\n");
}
