#include <stdio.h>

void here(void);
void there(void);

int main()
{
	here();
	there();
	return(0);
}

void here(void)
{
	int a,b;

	a=6+5;
	b=6*5;
	printf("Here: a = %d, b = %d\n",a,b);
}

void there(void)
{
	int b,a;

	a++;
	b++;
	printf("There: a = %d, b = %d\n",a,b);
}

