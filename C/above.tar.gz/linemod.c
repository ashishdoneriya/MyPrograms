#include <stdio.h>
#include <string.h>

void shout(void);
void showline(void);
void dashes(void);

char line[81];
int linelen;

int main()
{
	puts("Enter a line of text:");
	gets(line);
	linelen = strlen(line);

	puts("Here is the line you entered:");
	showline();
	puts("Here is the line in upper case:");
	shout();
	return(0);
}

void shout(void)
{
	int x = 0;

	dashes();		/* line above */
	while(line[x])
	{
		putchar(toupper(line[x]));
		x++;
	}
	putchar('\n');
	dashes();		/* line below */
}

void showline(void)
{
	dashes();
	puts(line);
	dashes();
}

void dashes(void)
{
	int x;

	for(x=0;x<linelen;x++)
		putchar('-');
	putchar('\n');
}

