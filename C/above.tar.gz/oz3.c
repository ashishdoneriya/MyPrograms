#include <stdio.h>

#define LINE_LENGTH 40

int main()
{
	char actor[6][18] = {
		"Judy Garland",
		"Ray Bolger",
		"Bert Lahr",
		"Jack Haley",
		"Margaret Hamilton",
		"Frank Morgan"
	};
	int age[6] = { 17, 35, 44, 40, 37, 49 };
	char role[6][16] = {
		"Dorothy",
		"Scarecrow",
		"Cowardly Lion",
		"Tin Woodsman",
		"Wicked Witch",
		"The Wizard"
	};

	int line,x;
	
	puts("Wizard of Oz Database!\n");
	
/* draw the table heading */
	printf("%-18s %3s   %-15s\n","Actor","Age","Role");
	for(line=0;line<LINE_LENGTH;line++) putchar('-');
	putchar('\n');

/* display the data */
	for(x=0;x<6;x++)
		printf("%-18s %3d   %-15s\n",actor[x],age[x],role[x]);
	
	return(0);
}

