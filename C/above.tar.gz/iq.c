#include <stdio.h>

int main()
{
	float iq[] = { 20.0, 55.6, 100.3, 119.8, 27.1 };
	int worker;

	puts("My Co-Worker's IQs:");
	for(worker=0;worker<5;worker++)
	{
		printf("Student #%d, %5.1f\n",worker,iq[worker]);
	}
	return(0);
}

