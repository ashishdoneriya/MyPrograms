#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define RANGE 100
#define GUESSES 5

int main()
{
	int guess,number,turn;

	srand((unsigned)time(NULL));

	puts("Guessing Game!");

	number = rand() % RANGE + 1;	/* value from 1 to RANGE */

	printf("I'm thinking of a number from 1 to %d.\n",RANGE);
	printf("Can you guess what it is in less than %d guesses?\n",GUESSES+1);
	
	turn=0;
	while(turn<GUESSES)
	{
		printf("Enter guess #%d: ",turn+1);
		scanf("%d",&guess);
		if(guess == number)
		{
			puts("You got it!\n");
			break;
		}
		else if(guess < number)
			puts("Too low!");
		else
			puts("Too high!");
		turn++;
	}
	printf("The number was %d\n",number);
	return(0);
}

