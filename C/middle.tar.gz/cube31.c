#include <stdio.h>
#include <math.h>

int main()
{
	double cube;

	cube = pow(2.0,(double)1/3);
	printf("The cube root of 2 is %f\n",cube);
	return(0);
}

