#include <stdio.h>

int main()
{
	int c = 10;

	while(c>0)
		printf("%d\n",c--);
	return(0);
}

