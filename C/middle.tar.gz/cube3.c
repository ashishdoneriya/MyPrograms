#include <stdio.h>
#include <math.h>

int main()
{
	double cube;

	cube = cbrt(2.0);
	printf("The cube root of 2 is %f\n",cube);
	return(0);
}

