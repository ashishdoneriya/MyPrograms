#include <stdio.h>

#define PODS 50

int main()
{
	puts("Base 10:");
	printf("I must deliver %d pods to San Francisco.\n",PODS);
	return(0);
}

