#include <stdio.h>

int main()
{
	int c;

	c = 10;
	while(c>0)
	{
		printf("%d\n",c);
		c--;
	}
	return(0);
}

