#include <stdio.h>
#include <math.h>

int main()
{
	double sqroot2;

	sqroot2 = sqrt(2.0);
	printf("The square root of 2 is %f.\n",sqroot2);
	return(0);
}

