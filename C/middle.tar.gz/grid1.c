#include <stdio.h>

int main()
{
	int x = 1;
	char a;

	while(x<10)
	{
		a = 'A';
		while(a < 'J')
		{
			printf("%d%c\t",x,a);
			if(x==5 && a=='E') goto rescue;
			a++;
		}
		putchar('\n');
		x++;
	}
rescue:
	return(0);
}
	
