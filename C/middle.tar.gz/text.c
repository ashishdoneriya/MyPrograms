#include <stdio.h>

int main()
{
	char name1[] = "George Washington";
	char name2[] = "John Adams";
	char name3[] = "Thomas Jefferson";

	printf("%17s\n",name1);
	printf("%17s\n",name2);
	printf("%17s\n",name3);
	return(0);
}

