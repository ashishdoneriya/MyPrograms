#include <stdio.h>
#include <math.h>

int main()
{
	double s,p;

	s = sqrt(5.0);
	p = pow(5.0,0.5);
	printf("The square root of 5 is %f\n",s);
	printf("5 to the 1/2 power is %f\n",p);
	return(0);
}

