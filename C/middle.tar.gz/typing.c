#include <stdio.h>

int main()
{
	char ch;

	while(ch != '~')
	{
		ch = getchar();
	}
	return(0);
}

