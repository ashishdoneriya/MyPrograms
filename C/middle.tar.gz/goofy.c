#include <stdio.h>

int main()
{
	char c;

	for(c=0;c<128;c++)
		printf("%d\t",c);
	return(0);
}

