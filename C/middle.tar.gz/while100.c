#include <stdio.h>

int main()
{
	int a = 1;

	while(a<=100)
	{
		printf("%3d\t",a);
		a++;
	}
	return(0);
}

