#include <stdio.h>
#include <stdlib.h>

int main()
{
	long int hat;
	int loop;

	for(loop=0;loop<100;loop++)
	{
		hat = rand();
		printf("%d\t",hat);
	}
	return(0);
}

