#include <stdio.h>

int main()
{
	int age;

	printf("Enter your age in years:");
	scanf("%d",&age);
	printf("You are %X hexadecimal years old!\n",age);
	return(0);
}

