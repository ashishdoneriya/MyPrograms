#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
	long int hat;
	int loop;

	srand((unsigned)time(NULL));

	for(loop=0;loop<100;loop++)
	{
		hat = rand();
		hat %= 10;
		printf("%5d\t",hat);
	}
	return(0);
}

