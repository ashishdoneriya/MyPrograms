#include <stdio.h>
#include <stdlib.h>

int main()
{
	long int hat;
	int loop;
	int seed;

	printf("Enter a seed number:");
	scanf("%d",&seed);
	srand(seed);

	for(loop=0;loop<100;loop++)
	{
		hat = rand();
		printf("%5d\t",hat);
	}
	return(0);
}

