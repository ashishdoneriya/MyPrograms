#include <stdio.h>
#include <math.h>

int main()
{
	int value;
	double root;

	printf("Enter a value:");
	scanf("%d",&value);
	if(value<0)
	{
		puts("I cannot compute the root of a negative number.");
	}
	else
	{
		root = sqrt((double)value);
		printf("The square root of %d is %f.\n",value,root);
	}
	return(0);
}

