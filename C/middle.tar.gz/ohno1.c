#include <stdio.h>

int main()
{
	int naughty;

	for(naughty=0;naughty<10;naughty++)
		puts("Naughty, naughty!");
	return(0);
}

