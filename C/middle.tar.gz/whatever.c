#include <stdio.h>
#include <math.h>

int main()
{
	double answer;

	answer = pow(5.0,399.0);
	printf("5 to the 399th power is %G\n",answer);
	return(0);
}

