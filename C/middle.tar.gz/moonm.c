#include <stdio.h>

#define DISTANCE 378921.46	/* in kilometers */
#define PI 3.141
#define MILES 0.621371195

int main()
{
	float orbit;

	orbit = DISTANCE * 2 * PI * MILES;
	printf("The moon travels %f miles in one orbit.\n",orbit);
	return(0);
}

