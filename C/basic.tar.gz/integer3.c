#include <stdio.h>

int main()
{
	printf("Sigmund will be 75 in the year %d.\n",1952+75);
	return(0);
}

