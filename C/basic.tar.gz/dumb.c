int main()
{
	puts("Greetings, human!");
	return(0);
}


