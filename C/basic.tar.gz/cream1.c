#include <stdio.h>

int main()
{
	printf("Two trips to the crematorium is %f miles.\n",13.5*2);
	return(0);
}

