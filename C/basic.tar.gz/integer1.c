#include <stdio.h>

int main()
{
	printf("Here's your integer value %d.\n",123+543);
	return(0);
}

