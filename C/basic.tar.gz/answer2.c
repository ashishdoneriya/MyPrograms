#include <stdio.h>

int main()
{
	int answer;

	answer = (4 + 5 - 2) * (6 / 3);
	printf("The answer is %d.\n",answer);
	return(0);
}

