#include <stdio.h>

int main()
{
	printf("I'm halfway to the crematorium, %f miles.\n",13.5/2);
	return(0);
}

