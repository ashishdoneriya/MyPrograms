#include <stdio.h>

int main()
{
	int age;

	printf("Enter your age in years:");
	scanf("%d",&age);
	printf("You are %d years old.\n",age);
	age += 25;
	if(age>100)
	{
		printf("In 25 years you'll probably be dead!\n");
	}
	else
	{
		printf("In 25 years you'll be %d years old.\n",age);
	}
	return(0);
}

