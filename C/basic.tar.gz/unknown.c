#include <stdio.h>

int main()
{
	int unknown;

	unknown = 5 * 2 * 6 / 6 / 2;

	printf("The unknown value is %d.\n",unknown);
	return(0);
}

