#include <stdio.h>

int main()
{
	char oz;

	oz = 'O';	/* the letter O */
	printf("Thsi book covers subject from %c",oz);
	oz = 'Z';
	printf(" to %c.\n",oz);
	return(0);
}

