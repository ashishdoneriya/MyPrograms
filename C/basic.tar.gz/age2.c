#include <stdio.h>

int main()
{
	int age;

	age = 43;	/* put your age here */
	printf("You are %d years old.\n",age);
	age += 5;
	printf("In five years you'll be %d years old.\n",age);
	return(0);
}

