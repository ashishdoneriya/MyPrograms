#include <stdio.h>

int main()
{
	int weight;

	weight = 210;		/* put your weight here */
	weight = weight - 20;
	printf("You weigh %d? That's not what your driver's license says!\n",weight);
	return(0);
}

