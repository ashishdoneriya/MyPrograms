#include <stdio.h>

int main()
{
	float duration;

	duration = 378921.46 / 140;

	printf("It would take %f hours to drive to the moon.\n",duration);
	return(0);
}

