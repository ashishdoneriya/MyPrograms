#include <stdio.h>

int main()
{
	printf("Sorry, can't talk now.\n");
	printf("I'm busy!");
	return(0);
}

