#include <stdio.h>

int main()
{
	int age;
	float distance;

	printf("The alien is %d years old and\n",age);
	printf("comes from a planet %f microns away!\n",distance);
	return(0);
}

