#include <stdio.h>

int main()
{
	int c;

	for(c=0;c<100;c++)
	{
		puts("I shall refrain from calling my friends names.");
	}
	return(0);
}

