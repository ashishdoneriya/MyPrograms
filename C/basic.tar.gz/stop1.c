#include <stdio.h>

int main()
{
	puts("Stop: Unable to stop.");
	puts("Missing fragus found in memory.");
	return(0);
}

