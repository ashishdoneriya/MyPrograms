#include <stdio.h>

int main()
{
	char letter,number;

	printf("What is your favorite letter?");
	letter = getchar();
	printf("What is your favorite number?");
	number = getchar();
	printf("Thank you!\n%c is our favorite letter and %c is your foavite number.\n",letter,number);
	return(0);
}

