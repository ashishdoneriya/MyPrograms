#include <stdio.h>

int main()
{
	int distance = 2;

	printf("You have to walk only %d mils to school.\n",distance);
	distance *= 25;
	printf("But when I was a kid, I walked %d miles to school!\n",distance);
	printf("Both ways!\n");
	printf("In the snow!\n");
	printf("Up hill!\n");
	return(0);
}

