#include <stdio.h>

int main()
{
	int countdown;

	for(countdown=10;countdown>0;countdown=countdown-1)
	{
		printf("%d\n",countdown);
	}
	printf("%d, Blastoff!\n",countdown);
	return(0);
}

