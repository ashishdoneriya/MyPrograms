/* STOP.C source code. By Dan Gookin. March 4, 2004 */

#include <stdio.h>

int main()
{

/* NOTE: added a beep to the following line
   The \a is the Alert or bell character */
	
	puts("\aStop: Unable to stop.");
	puts("Missing fragus found in memory.");
	return(0);
}

