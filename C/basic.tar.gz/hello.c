#include <stdio.h>

int main()
{
	printf("Sorry, can't talk now.");
	printf("I'm busy!");
	return(0);
}

