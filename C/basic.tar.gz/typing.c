#include <stdio.h>

int main()
{
	char ch;

	puts("Typing Program");
	puts("Type away:");
	for(;;)
	{
		ch=getchar();
	}
	return(0);
}

