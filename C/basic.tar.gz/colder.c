#include <stdio.h>

int main()
{
	int t;

	t = 50;
	printf("You may think it's cold at %d,\n",t);
	printf("but at %d it's colder!\n",-t);
	return(0);
}

