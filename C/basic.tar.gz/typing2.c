#include <stdio.h>

int main()
{
	char ch;

	puts("Typing Program");
	puts("Type away; press '~' or '`' to quit:");
	for(;;)
	{
		ch=getchar();
		if(ch=='~' || ch=='`')
		{
			break;
		}
	}
	return(0);
}

