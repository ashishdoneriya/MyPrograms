#include <stdio.h>

int main()
{
	int answer;

	answer = 7 + 8 - 3 * 4 / 2;
	printf("The answer is %d.\n",answer);
	return(0);
}

