#include <stdio.h>

#define TOTAL 300

int main()
{
	int count;

	for(count=0;count<TOTAL;count++)
		printf("I think I'm going to be sick! ");
}

