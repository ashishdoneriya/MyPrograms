#include <stdio.h>

int main()
{
	printf("It's %f miles to the crematorium.\n",13.5);
	return(0);
}

