#include <stdio.h>

int main()
{
	int total,fine,speeding;
	int speedlimit,rate,first_ticket,second_ticket,third_ticket;

	speedlimit = 55;
	rate = 15;
	first_ticket = 85;
	second_ticket = 95;
	third_ticket = 100;

	puts("Speeding Tickets\n");

/* first ticket */

	speeding = first_ticket - speedlimit;	/* mph over limit */
	fine = speeding * rate;		/* $ fine per mph over limit */
	total = total + fine;
	printf("For going %d in a %d zone: $%d\n",first_ticket,speedlimit,fine);

/* second ticket */

	speeding = second_ticket - speedlimit;
	fine = speeding * rate;
	total = total + fine;
	printf("For going %d in a %d zone: $%d\n",second_ticket,speedlimit,fine);

/* third ticket */

	speeding = third_ticket - speedlimit;
	fine = speeding * rate;
	total = total + fine;
	printf("For going %d in a %d zone: $%d\n",third_ticket,speedlimit,fine);

/* Display total */

	printf("\nTotal in fines: $%d\n",total);
	return(0);
}

