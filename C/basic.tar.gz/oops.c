#include <stdio.h>

int main()
{
	print("Hello, geek!/n")
	return;
}

