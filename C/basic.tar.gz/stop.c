#include <stdio.h>

int main()
{
	puts("Stop: Unable to stop.");
	return(0);
}

