#include <stdio.h>

int main()
{
	printf("This program is sponsored by the letter '%c'\n",'P');
	return(0);
}

