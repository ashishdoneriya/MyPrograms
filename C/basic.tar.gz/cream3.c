#include <stdio.h>

int main()
{
	printf("The new crematorium is %f miles further.\n",19.2-13.5);
	return(0);
}

