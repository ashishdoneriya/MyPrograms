#include <stdio.h>

int main()
{
	char ch;

	printf("Would you like me to send your password to the bad guys?\n");
	printf("Enter Y or N (Y/N)?");
	ch = getchar();
	if(ch=='N')
	{
		printf("Well, then: your password is safe!\n");
	}
	else
	{
		printf("Okay. Sending your passsword!\n");
	}
	return(0);
}

