#include <stdio.h>

#define BEGIN int main()
#define HELLO {
#define WRITELN printf
#define END_CODE return(0);
#define BYE }

BEGIN
HELLO
WRITELN("What the heck is going on?\n");
END_CODE
BYE

