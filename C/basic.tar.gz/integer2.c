#include <stdio.h>

int main()
{
	printf("Shakespeare lived %d years.\n",1616-1564);
	return(0);
}

