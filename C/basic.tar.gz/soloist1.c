#include <stdio.h>

int main()
{
	printf("The First Soloist\n\n");	/* Extra blank line */
	printf("Vocalist Mary McDiva\n");
	printf("Song, \"Under the Sea.\"\n");
	return(0);
}

